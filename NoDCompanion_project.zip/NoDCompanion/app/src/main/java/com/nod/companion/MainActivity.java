package com.nod.companion;

import android.app.AlertDialog;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;

public class MainActivity extends Activity {
    // После создания Firebase Realtime Database заменим это значение на ваш URL,
    // например: https://nod-companion-default-rtdb.europe-west1.firebasedatabase.app
    private static final String FIREBASE_URL = "https://nodcompanion-bc8cb-default-rtdb.europe-west1.firebasedatabase.app";
    private static final String FIREBASE_API_KEY = "AIzaSyCGDcPyyeZHGxk9TxWnBTTjRU6UxEi1ob4";
    private final Object firebaseAuthLock = new Object();
    private volatile String firebaseIdToken = "";
    private volatile long firebaseTokenExpiryMs = 0L;

    CompanionView view;
    SharedPreferences prefs;
    FrameLayout root;
    FrameLayout contentOverlay;
    Handler handler = new Handler(Looper.getMainLooper());
    Runnable refreshRunnable;
    boolean polling = false;
    ListView messageList;
    MessageAdapter messageAdapter;
    final ArrayList<ChatMessage> messages = new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(36,19,28));
        w.setNavigationBarColor(Color.rgb(9,7,12));
        prefs = getSharedPreferences("nod", MODE_PRIVATE);

        root = new FrameLayout(this);
        view = new CompanionView(this);
        root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        contentOverlay = new FrameLayout(this);
        FrameLayout.LayoutParams op = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        op.setMargins(dp(20), dp(105), dp(20), dp(145));
        root.addView(contentOverlay, op);
        contentOverlay.setVisibility(View.GONE);

        setContentView(root);

        refreshRunnable = new Runnable() {
            @Override public void run() {
                if (!polling) return;
                fetchMessages();
                handler.postDelayed(this, 3000);
            }
        };
    }

    int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    boolean backendConfigured() {
        return FIREBASE_URL.startsWith("https://") && !FIREBASE_URL.contains("PASTE_");
    }

    GradientDrawable bg(int color, float radiusDp, int strokeColor, float strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    TextView tv(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setTypeface(android.graphics.Typeface.DEFAULT, bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        return t;
    }

    EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF827A82);
        e.setTextColor(Color.WHITE);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setPadding(dp(16), 0, dp(16), 0);
        e.setBackground(bg(0xFF181219, 16, 0xFF44333E, 1));
        return e;
    }

    LinearLayout.LayoutParams lpMatch(int hDp) {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(hDp));
    }

    LinearLayout.LayoutParams lpMatchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    public void showLanguageDialog() {
        final String[] names = {"Русский","English","Français","简体中文","Español","العربية","हिन्दी","Português","Deutsch","日本語"};
        int checked = view.language;
        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle(view.tr("Выберите язык","Choose language","Choisissez la langue","选择语言","Elige idioma","اختر اللغة","भाषा चुनें","Escolha o idioma","Sprache wählen","言語を選択"))
                .setSingleChoiceItems(names, checked, (dialog, which) -> {
                    view.language = which;
                    prefs.edit().putInt("lang", which).apply();
                    view.invalidate();
                    if (view.screen == 1 && view.tab == 1) showChatSection();
                    dialog.dismiss();
                })
                .setNegativeButton(view.tr("ОТМЕНА","CANCEL","ANNULER","取消","CANCELAR","إلغاء","रद्द करें","CANCELAR","ABBRECHEN","キャンセル"), null)
                .create();
        dlg.setOnShowListener(d -> {
            if (dlg.getWindow() != null) dlg.getWindow().setBackgroundDrawable(new ColorDrawable(Color.rgb(68,68,68)));
            dlg.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.rgb(185,71,100));
        });
        dlg.show();
    }

    void onTabChanged(int tab) {
        if (tab == 1) {
            contentOverlay.setVisibility(View.VISIBLE);
            showChatSection();
        } else {
            contentOverlay.setVisibility(View.GONE);
            stopPolling();
            hideKeyboard();
        }
    }

    void showChatSection() {
        contentOverlay.removeAllViews();
        if (!prefs.getBoolean("registered", false)) {
            stopPolling();
            showRegistration();
        } else {
            showChat();
            startPolling();
        }
    }

    void showRegistration() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        contentOverlay.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER_HORIZONTAL);
        wrap.setPadding(dp(8), dp(18), dp(8), dp(8));
        scroll.addView(wrap, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = tv(view.tr("Регистрация в чате","Chat registration","Inscription au chat","聊天注册","Registro del chat","تسجيل الدردشة","चैट पंजीकरण","Registro no chat","Chat-Registrierung","チャット登録"), 25, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        wrap.addView(title, lpMatchWrap());

        TextView sub = tv(view.tr(
                "Заполните данные один раз. Они сохранятся на этом телефоне.",
                "Enter your details once. They will stay saved on this phone.",
                "Saisissez vos données une fois. Elles resteront enregistrées sur ce téléphone.",
                "只需填写一次，信息将保存在此手机上。",
                "Introduce tus datos una vez. Se guardarán en este teléfono.",
                "أدخل بياناتك مرة واحدة. ستبقى محفوظة على هذا الهاتف.",
                "जानकारी एक बार भरें। यह इस फ़ोन पर सहेजी रहेगी।",
                "Preencha seus dados uma vez. Eles ficarão salvos neste telefone.",
                "Daten einmal eingeben. Sie bleiben auf diesem Telefon gespeichert.",
                "一度入力すれば、この端末に保存されます。"), 14, 0xFFA9A1A8, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(dp(18), dp(8), dp(18), dp(22));
        wrap.addView(sub, lpMatchWrap());

        EditText server = edit(view.tr("Номер сервера","Server number","Numéro du serveur","服务器编号","Número de servidor","رقم الخادم","सर्वर नंबर","Número do servidor","Servernummer","サーバー番号"));
        server.setInputType(InputType.TYPE_CLASS_NUMBER);
        wrap.addView(server, lpMatch(56));

        Space s1 = new Space(this); wrap.addView(s1, new LinearLayout.LayoutParams(1, dp(12)));

        EditText alliance = edit(view.tr("Альянс — 3 буквы, например WEE","Alliance — 3 letters, e.g. WEE","Alliance — 3 lettres, ex. WEE","联盟 — 3 个字母，例如 WEE","Alianza — 3 letras, p. ej. WEE","التحالف — 3 أحرف، مثال WEE","गठबंधन — 3 अक्षर, जैसे WEE","Aliança — 3 letras, ex. WEE","Allianz — 3 Buchstaben, z. B. WEE","同盟 — 3文字、例 WEE"));
        alliance.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        alliance.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});
        final boolean[] allianceEditing = {false};
        alliance.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int st, int before, int count) {}
            @Override public void afterTextChanged(Editable e) {
                if (allianceEditing[0]) return;
                String clean = e.toString().toUpperCase(Locale.US).replaceAll("[^A-Z]", "");
                if (clean.length() > 3) clean = clean.substring(0,3);
                if (!clean.equals(e.toString())) {
                    allianceEditing[0] = true;
                    alliance.setText(clean);
                    alliance.setSelection(clean.length());
                    allianceEditing[0] = false;
                }
            }
        });
        wrap.addView(alliance, lpMatch(56));

        Space s2 = new Space(this); wrap.addView(s2, new LinearLayout.LayoutParams(1, dp(12)));

        EditText nick = edit(view.tr("Никнейм","Nickname","Pseudo","昵称","Apodo","الاسم المستعار","उपनाम","Apelido","Nickname","ニックネーム"));
        nick.setFilters(new InputFilter[]{new InputFilter.LengthFilter(24)});
        wrap.addView(nick, lpMatch(56));

        Space s3 = new Space(this); wrap.addView(s3, new LinearLayout.LayoutParams(1, dp(18)));

        Button register = new Button(this);
        register.setAllCaps(false);
        register.setText(view.tr("Зарегистрироваться","Register","S'inscrire","注册","Registrarse","تسجيل","रजिस्टर करें","Registrar","Registrieren","登録"));
        register.setTextColor(Color.WHITE);
        register.setTextSize(16);
        register.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        register.setBackground(bg(0xFFB94764, 18, 0, 0));
        wrap.addView(register, lpMatch(58));

        TextView error = tv("", 13, 0xFFFF7B8F, false);
        error.setGravity(Gravity.CENTER);
        error.setPadding(dp(8), dp(12), dp(8), 0);
        wrap.addView(error, lpMatchWrap());

        register.setOnClickListener(v -> {
            String sv = server.getText().toString().trim();
            String al = alliance.getText().toString().trim().toUpperCase(Locale.US);
            String ni = nick.getText().toString().trim();
            if (sv.length() == 0 || !sv.matches("[0-9]+")) {
                error.setText(view.tr("Введите номер сервера.","Enter the server number.","Entrez le numéro du serveur.","请输入服务器编号。","Introduce el número del servidor.","أدخل رقم الخادم.","सर्वर नंबर दर्ज करें।","Digite o número do servidor.","Servernummer eingeben.","サーバー番号を入力してください。"));
                return;
            }
            if (!al.matches("[A-Z]{3}")) {
                error.setText(view.tr("Альянс должен состоять ровно из 3 латинских букв.","Alliance must be exactly 3 Latin letters.","L'alliance doit contenir exactement 3 lettres latines.","联盟必须正好是 3 个英文字母。","La alianza debe tener exactamente 3 letras latinas.","يجب أن يتكون التحالف من 3 أحرف لاتينية بالضبط.","गठबंधन में ठीक 3 लैटिन अक्षर होने चाहिए।","A aliança deve ter exatamente 3 letras latinas.","Die Allianz muss genau 3 lateinische Buchstaben haben.","同盟は英字3文字ちょうどにしてください。"));
                return;
            }
            if (ni.length() < 2) {
                error.setText(view.tr("Введите никнейм.","Enter a nickname.","Entrez un pseudo.","请输入昵称。","Introduce un apodo.","أدخل اسماً مستعاراً.","उपनाम दर्ज करें।","Digite um apelido.","Nickname eingeben.","ニックネームを入力してください。"));
                return;
            }
            String userId = prefs.getString("user_id", "");
            if (userId.length() == 0) userId = UUID.randomUUID().toString();
            prefs.edit()
                    .putBoolean("registered", true)
                    .putString("server", sv)
                    .putString("alliance", al)
                    .putString("nick", ni)
                    .putString("user_id", userId)
                    .apply();
            hideKeyboard();
            new Thread(() -> {
                try { ensureFirebaseProfile(); } catch (Exception ignored) {}
            }).start();
            showChatSection();
        });
    }

    void showChat() {
        FrameLayout panel = new FrameLayout(this);
        contentOverlay.addView(panel, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        panel.addView(col, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(8), dp(4), dp(8), dp(10));
        TextView title = tv(view.tr("Общий чат","Global chat","Chat global","公共聊天","Chat global","الدردشة العامة","सार्वजनिक चैट","Chat geral","Allgemeiner Chat","全体チャット"), 22, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        header.addView(title, lpMatchWrap());
        String identity = "[" + prefs.getString("server", "?") + "] [" + prefs.getString("alliance", "???") + "] " + prefs.getString("nick", "");
        TextView me = tv(identity, 13, 0xFFD7B88A, false);
        me.setGravity(Gravity.CENTER);
        header.addView(me, lpMatchWrap());
        col.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        if (!backendConfigured()) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setPadding(dp(22), dp(22), dp(22), dp(22));
            card.setBackground(bg(0xD8231820, 22, 0xFF493642, 1));
            TextView t = tv(view.tr("Чат почти готов","Chat is almost ready","Le chat est presque prêt","聊天即将就绪","El chat casi está listo","الدردشة جاهزة تقريباً","चैट लगभग तैयार है","O chat está quase pronto","Chat ist fast fertig","チャットはほぼ準備完了"), 22, Color.WHITE, true);
            t.setGravity(Gravity.CENTER); card.addView(t, lpMatchWrap());
            TextView d = tv(view.tr(
                    "Регистрация уже работает и сохранена. Осталось подключить онлайн-базу Firebase — после этого сообщения будут общими для всех игроков.",
                    "Registration already works and is saved. We only need to connect Firebase; then messages will be shared by all players.",
                    "L'inscription fonctionne déjà et est enregistrée. Il reste à connecter Firebase pour partager les messages entre tous les joueurs.",
                    "注册已可用并已保存。只需连接 Firebase，所有玩家即可共享消息。",
                    "El registro ya funciona y se guarda. Solo falta conectar Firebase para que los mensajes sean compartidos por todos.",
                    "التسجيل يعمل ويتم حفظه. بقي فقط ربط Firebase لتصبح الرسائل مشتركة بين جميع اللاعبين.",
                    "पंजीकरण काम कर रहा है और सहेजा जाता है। अब केवल Firebase जोड़ना है ताकि सभी खिलाड़ी एक ही चैट देखें।",
                    "O registro já funciona e fica salvo. Só falta conectar o Firebase para que as mensagens sejam compartilhadas entre todos.",
                    "Die Registrierung funktioniert bereits und bleibt gespeichert. Jetzt muss nur noch Firebase verbunden werden, damit alle Spieler denselben Chat sehen.",
                    "登録はすでに動作し保存されます。あとは Firebase を接続すれば、全プレイヤーで同じメッセージを共有できます。"), 15, 0xFFBEB5BC, false);
            d.setGravity(Gravity.CENTER); d.setPadding(0, dp(12), 0, 0); card.addView(d, lpMatchWrap());
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            cp.setMargins(dp(6), dp(36), dp(6), 0);
            col.addView(card, cp);
            return;
        }

        messageList = new ListView(this);
        messageList.setDivider(new ColorDrawable(Color.TRANSPARENT));
        messageList.setDividerHeight(dp(7));
        messageList.setSelector(new ColorDrawable(Color.TRANSPARENT));
        messageList.setCacheColorHint(Color.TRANSPARENT);
        messageList.setBackgroundColor(Color.TRANSPARENT);
        messageAdapter = new MessageAdapter(this, messages);
        messageList.setAdapter(messageAdapter);
        LinearLayout.LayoutParams listLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        col.addView(messageList, listLp);

        LinearLayout sendBar = new LinearLayout(this);
        sendBar.setOrientation(LinearLayout.HORIZONTAL);
        sendBar.setGravity(Gravity.CENTER_VERTICAL);
        sendBar.setPadding(0, dp(8), 0, 0);
        EditText input = edit(view.tr("Сообщение…","Message…","Message…","消息…","Mensaje…","رسالة…","संदेश…","Mensagem…","Nachricht…","メッセージ…"));
        input.setSingleLine(false);
        input.setMaxLines(3);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(500)});
        LinearLayout.LayoutParams inLp = new LinearLayout.LayoutParams(0, dp(54), 1f);
        sendBar.addView(input, inLp);
        Space gap = new Space(this); sendBar.addView(gap, new LinearLayout.LayoutParams(dp(8), 1));
        Button send = new Button(this);
        send.setText("➤");
        send.setTextSize(22);
        send.setTextColor(Color.WHITE);
        send.setBackground(bg(0xFFB94764, 16, 0, 0));
        sendBar.addView(send, new LinearLayout.LayoutParams(dp(58), dp(54)));
        col.addView(sendBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        send.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            if (text.length() == 0) return;
            sendMessage(text, input, send);
        });

        fetchMessages();
    }

    void startPolling() {
        if (!backendConfigured()) return;
        polling = true;
        handler.removeCallbacks(refreshRunnable);
        handler.post(refreshRunnable);
    }

    void stopPolling() {
        polling = false;
        handler.removeCallbacks(refreshRunnable);
    }

    void sendMessage(String text, EditText input, Button send) {
        send.setEnabled(false);
        final String sv = prefs.getString("server", "");
        final String al = prefs.getString("alliance", "");
        final String ni = prefs.getString("nick", "");
        final String uid = prefs.getString("user_id", "");
        new Thread(() -> {
            try {
                JSONObject j = new JSONObject();
                String firebaseUid = ensureFirebaseProfile();
                j.put("uid", firebaseUid);
                j.put("server", sv);
                j.put("alliance", al);
                j.put("nickname", ni);
                j.put("text", text);
                j.put("timestamp", System.currentTimeMillis());
                request("POST", authenticatedEndpoint("messages.json"), j.toString());
                runOnUiThread(() -> {
                    input.setText("");
                    send.setEnabled(true);
                    fetchMessages();
                });
            } catch (Exception ex) {
                runOnUiThread(() -> {
                    send.setEnabled(true);
                    Toast.makeText(MainActivity.this, view.tr("Не удалось отправить сообщение","Could not send message","Impossible d'envoyer le message","无法发送消息","No se pudo enviar el mensaje","تعذر إرسال الرسالة","संदेश भेजा नहीं जा सका","Não foi possível enviar a mensagem","Nachricht konnte nicht gesendet werden","メッセージを送信できませんでした"), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    void fetchMessages() {
        if (!backendConfigured()) return;
        new Thread(() -> {
            try {
                String body = request("GET", authenticatedEndpoint("messages.json"), null);
                ArrayList<ChatMessage> fresh = new ArrayList<>();
                if (body != null && !body.trim().equals("null") && body.trim().startsWith("{")) {
                    JSONObject all = new JSONObject(body);
                    Iterator<String> keys = all.keys();
                    while (keys.hasNext()) {
                        String key = keys.next();
                        JSONObject m = all.optJSONObject(key);
                        if (m == null) continue;
                        ChatMessage cm = new ChatMessage();
                        cm.server = m.optString("server", "?");
                        cm.alliance = m.optString("alliance", "???");
                        cm.nick = m.optString("nickname", "Player");
                        cm.text = m.optString("text", "");
                        cm.timestamp = m.optLong("timestamp", 0);
                        cm.userId = m.optString("uid", "");
                        if (cm.text.length() > 0) fresh.add(cm);
                    }
                }
                Collections.sort(fresh, Comparator.comparingLong(a -> a.timestamp));
                if (fresh.size() > 100) fresh = new ArrayList<>(fresh.subList(fresh.size()-100, fresh.size()));
                final ArrayList<ChatMessage> finalFresh = fresh;
                runOnUiThread(() -> {
                    messages.clear();
                    messages.addAll(finalFresh);
                    if (messageAdapter != null) messageAdapter.notifyDataSetChanged();
                    if (messageList != null && messages.size() > 0) messageList.setSelection(messages.size()-1);
                });
            } catch (Exception ignored) { }
        }).start();
    }


    String ensureFirebaseProfile() throws Exception {
        String token = getFirebaseIdToken();
        String uid = getFirebaseUid(token);
        JSONObject profile = new JSONObject();
        profile.put("server", prefs.getString("server", ""));
        profile.put("alliance", prefs.getString("alliance", ""));
        profile.put("nickname", prefs.getString("nick", ""));
        request("PUT",
                endpoint("users/" + uid + ".json") + "?auth=" + URLEncoder.encode(token, "UTF-8"),
                profile.toString());
        return uid;
    }

    String getFirebaseUid(String token) throws Exception {
        String uid = prefs.getString("firebase_uid", "");
        if (uid.length() > 0) return uid;

        JSONObject payload = new JSONObject();
        payload.put("idToken", token);
        JSONObject lookup = new JSONObject(request(
                "POST",
                "https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=" + FIREBASE_API_KEY,
                payload.toString()));
        if (lookup.optJSONArray("users") != null && lookup.optJSONArray("users").length() > 0) {
            uid = lookup.optJSONArray("users").optJSONObject(0).optString("localId", "");
        }
        if (uid.length() == 0) throw new RuntimeException("Firebase uid missing");
        prefs.edit().putString("firebase_uid", uid).apply();
        return uid;
    }

    String authenticatedEndpoint(String path) throws Exception {
        String token = getFirebaseIdToken();
        return endpoint(path) + "?auth=" + URLEncoder.encode(token, "UTF-8");
    }

    String getFirebaseIdToken() throws Exception {
        long now = System.currentTimeMillis();
        if (firebaseIdToken.length() > 0 && now < firebaseTokenExpiryMs) return firebaseIdToken;
        synchronized (firebaseAuthLock) {
            now = System.currentTimeMillis();
            if (firebaseIdToken.length() > 0 && now < firebaseTokenExpiryMs) return firebaseIdToken;

            String refresh = prefs.getString("firebase_refresh_token", "");
            if (refresh.length() > 0) {
                try {
                    JSONObject refreshed = new JSONObject(formRequest(
                            "https://securetoken.googleapis.com/v1/token?key=" + FIREBASE_API_KEY,
                            "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refresh, "UTF-8")));
                    firebaseIdToken = refreshed.optString("id_token", "");
                    String newRefresh = refreshed.optString("refresh_token", refresh);
                    long expires = Long.parseLong(refreshed.optString("expires_in", "3600"));
                    firebaseTokenExpiryMs = System.currentTimeMillis() + Math.max(60, expires - 120) * 1000L;
                    prefs.edit().putString("firebase_refresh_token", newRefresh).apply();
                    if (firebaseIdToken.length() > 0) return firebaseIdToken;
                } catch (Exception ignored) {
                    prefs.edit().remove("firebase_refresh_token").apply();
                }
            }

            JSONObject signed = new JSONObject(request(
                    "POST",
                    "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + FIREBASE_API_KEY,
                    "{\"returnSecureToken\":true}"));
            firebaseIdToken = signed.optString("idToken", "");
            String newRefresh = signed.optString("refreshToken", "");
            String firebaseUid = signed.optString("localId", "");
            long expires = Long.parseLong(signed.optString("expiresIn", "3600"));
            firebaseTokenExpiryMs = System.currentTimeMillis() + Math.max(60, expires - 120) * 1000L;
            SharedPreferences.Editor authEdit = prefs.edit();
            if (newRefresh.length() > 0) authEdit.putString("firebase_refresh_token", newRefresh);
            if (firebaseUid.length() > 0) authEdit.putString("firebase_uid", firebaseUid);
            authEdit.apply();
            if (firebaseIdToken.length() == 0) throw new RuntimeException("Firebase anonymous auth failed");
            return firebaseIdToken;
        }
    }

    String formRequest(String url, String formBody) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        byte[] data = formBody.getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = c.getOutputStream()) { os.write(data); }
        int code = c.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line; while ((line = br.readLine()) != null) sb.append(line);
            }
        }
        c.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("HTTP " + code + ": " + sb);
        return sb.toString();
    }

    String endpoint(String path) {
        String base = FIREBASE_URL.endsWith("/") ? FIREBASE_URL.substring(0, FIREBASE_URL.length()-1) : FIREBASE_URL;
        return base + "/" + path;
    }

    String request(String method, String url, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        c.setRequestProperty("Accept", "application/json");
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            byte[] data = body.getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = c.getOutputStream()) { os.write(data); }
        }
        int code = c.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line; while ((line = br.readLine()) != null) sb.append(line);
            }
        }
        c.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("HTTP " + code + ": " + sb);
        return sb.toString();
    }

    void hideKeyboard() {
        View f = getCurrentFocus();
        if (f != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(f.getWindowToken(), 0);
            f.clearFocus();
        }
    }

    @Override protected void onPause() {
        super.onPause();
        stopPolling();
    }

    @Override protected void onResume() {
        super.onResume();
        if (view != null && view.screen == 1 && view.tab == 1 && prefs.getBoolean("registered", false)) startPolling();
    }

    static class ChatMessage {
        String server, alliance, nick, text, userId;
        long timestamp;
    }

    class MessageAdapter extends BaseAdapter {
        final Context ctx;
        final List<ChatMessage> data;
        final SimpleDateFormat time = new SimpleDateFormat("HH:mm", Locale.getDefault());
        MessageAdapter(Context c, List<ChatMessage> d) { ctx=c; data=d; }
        @Override public int getCount(){ return data.size(); }
        @Override public Object getItem(int p){ return data.get(p); }
        @Override public long getItemId(int p){ return p; }
        @Override public View getView(int pos, View convert, ViewGroup parent) {
            ChatMessage m = data.get(pos);
            LinearLayout card = new LinearLayout(ctx);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(13), dp(9), dp(13), dp(9));
            boolean mine = prefs.getString("firebase_uid", "").equals(m.userId);
            card.setBackground(bg(mine ? 0xD54B2835 : 0xC91B151C, 15, mine ? 0xFF6B3D4D : 0xFF382B34, 1));

            LinearLayout top = new LinearLayout(ctx);
            top.setOrientation(LinearLayout.HORIZONTAL);
            TextView who = tv("["+m.server+"] ["+m.alliance+"] "+m.nick, 13, mine ? 0xFFD7B88A : 0xFFE2D9DF, true);
            top.addView(who, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView tm = tv(m.timestamp > 0 ? time.format(new Date(m.timestamp)) : "", 11, 0xFF817780, false);
            top.addView(tm, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            card.addView(top, lpMatchWrap());

            TextView msg = tv(m.text, 16, Color.WHITE, false);
            msg.setPadding(0, dp(5), 0, 0);
            msg.setTextIsSelectable(true);
            card.addView(msg, lpMatchWrap());
            return card;
        }
    }

    class CompanionView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap castle, face;
        int screen = 0; // 0 intro, 1 main
        int tab = 0; // 0 info, 1 chat
        int language;
        float[] sx = new float[24], sy = new float[24], sr = new float[24];
        RectF langRect = new RectF(), buttonRect = new RectF(), navRect = new RectF(), infoRect = new RectF(), chatRect = new RectF();

        CompanionView(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            castle = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("castle","drawable",getPackageName()));
            face = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("face_logo","drawable",getPackageName()));
            language = prefs.getInt("lang", 0);
            Random r = new Random(14);
            for (int i=0;i<sx.length;i++) { sx[i]=r.nextFloat(); sy[i]=r.nextFloat(); sr[i]=0.8f+r.nextFloat()*1.6f; }
            stroke.setStyle(Paint.Style.STROKE);
        }

        String tr(String... v) { return v[Math.max(0, Math.min(language, v.length-1))]; }
        String langCode() { return new String[]{"RU","EN","FR","中文","ES","AR","HI","PT","DE","日本"}[language]; }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            Paint bg=new Paint();
            bg.setShader(new LinearGradient(0,0,0,h,Color.rgb(38,19,29),Color.rgb(9,7,12),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,bg);
            Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
            halo.setShader(new RadialGradient(w*.66f,h*.1f,w*.6f,new int[]{0x302F0D1A,0x00100010},null,Shader.TileMode.CLAMP));
            c.drawCircle(w*.66f,h*.1f,w*.6f,halo);
            drawStars(c,w,h);
            if(screen==0) drawIntro(c,w,h); else drawMain(c,w,h);
        }

        void drawStars(Canvas c,float w,float h){
            p.setColor(0x305F5060);
            for(int i=0;i<sx.length;i++) c.drawCircle(sx[i]*w, sy[i]*h, sr[i], p);
        }

        void drawIntro(Canvas c,float w,float h){
            float s=w/691f;
            RectF fr=new RectF(49*s,48*s,116*s,115*s); c.drawBitmap(face,null,fr,p);
            p.setColor(Color.rgb(215,184,138)); p.setTextSize(18*s); p.setTypeface(Typeface.create("sans",Typeface.NORMAL));
            c.drawText("N O D   C O M P A N I O N",132*s,90*s,p);
            langRect.set(w-183*s,42*s,w-48*s,118*s); drawRounded(c,langRect,20*s,0x15100C14,0xFF3B2D36,2*s);
            drawGlobe(c,langRect.left+40*s,langRect.centerY(),12*s,Color.rgb(215,184,138));
            p.setColor(Color.WHITE); p.setTextSize(20*s); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(langCode(),langRect.left+65*s,langRect.centerY()+7*s,p);
            p.setColor(Color.rgb(215,184,138)); p.setTextSize(12*s); c.drawText("▾",langRect.right-26*s,langRect.centerY()+3*s,p);

            float imageTop=245*s;
            float imageW=w-96*s;
            float imageH=imageW*castle.getHeight()/castle.getWidth();
            RectF cr=new RectF(48*s,imageTop,w-48*s,imageTop+imageH);
            c.drawBitmap(castle,null,cr,p);

            p.setColor(Color.rgb(248,246,244)); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(43*s);
            c.drawText("NATIONS OF",w/2,cr.bottom+72*s,p); c.drawText("DARKNESS",w/2,cr.bottom+146*s,p);
            p.setColor(Color.rgb(170,163,169)); p.setTextSize(22*s); c.drawText(tr(
                "Твой помощник в мире тьмы.","Your companion in the world of darkness.","Votre compagnon dans le monde des ténèbres.","你在黑暗世界中的助手。","Tu compañero en el mundo de la oscuridad.","رفيقك في عالم الظلام.","अंधकार की दुनिया में आपका साथी।","Seu companheiro no mundo das trevas.","Dein Begleiter in der Welt der Dunkelheit.","闇の世界のあなたの相棒。"),w/2,cr.bottom+214*s,p);

            buttonRect.set(49*s,h-235*s,w-49*s,h-135*s); drawRounded(c,buttonRect,26*s,0xFFB94764,0x00000000,0);
            p.setColor(Color.WHITE); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(27*s); c.drawText(tr("Начать","Start","Commencer","开始","Comenzar","ابدأ","शुरू करें","Começar","Starten","開始"),w/2,buttonRect.centerY()+9*s,p);
            p.setColor(Color.rgb(126,118,126)); p.setTypeface(Typeface.DEFAULT); p.setTextSize(17*s); c.drawText("Версия 0.5.0",w/2,h-53*s,p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        void drawMain(Canvas c,float w,float h){
            float s=w/691f;
            float cx=73*s, cy=72*s, rr=24*s;
            stroke.setStrokeWidth(1.2f*s); stroke.setColor(0x554D3D4B); c.drawCircle(cx,cy,rr+7*s,stroke); c.drawCircle(cx,cy,rr+2*s,stroke);
            p.setColor(Color.rgb(236,218,194)); c.drawCircle(cx-5*s,cy,9*s,p);
            p.setColor(Color.rgb(38,19,29)); c.drawCircle(cx-1*s,cy-3*s,9*s,p);
            p.setColor(Color.rgb(236,218,194)); c.drawCircle(cx+10*s,cy-9*s,1.8f*s,p); c.drawCircle(cx+14*s,cy+2*s,1.2f*s,p);
            p.setColor(Color.rgb(248,246,244)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(26*s); c.drawText("NoD Companion",120*s,82*s,p);

            langRect.set(w-176*s,35*s,w-42*s,112*s); drawRounded(c,langRect,22*s,0x12100B12,0xFF3C2D37,2*s);
            drawGlobe(c,langRect.left+37*s,langRect.centerY(),12*s,Color.rgb(215,184,138));
            p.setColor(Color.WHITE); p.setTextSize(20*s); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(langCode(),langRect.left+62*s,langRect.centerY()+7*s,p);
            p.setColor(Color.rgb(215,184,138)); p.setTextSize(12*s); c.drawText("▾",langRect.right-25*s,langRect.centerY()+3*s,p);

            navRect.set(28*s,h-178*s,w-28*s,h-62*s); drawRounded(c,navRect,34*s,0x15161119,0xFF3C2E39,2*s);
            infoRect.set(navRect.left+10*s,navRect.top+10*s,navRect.centerX()-4*s,navRect.bottom-10*s);
            chatRect.set(navRect.centerX()+4*s,navRect.top+10*s,navRect.right-10*s,navRect.bottom-10*s);
            RectF sel = tab==0 ? infoRect : chatRect; drawRounded(c,sel,26*s,0xFF4B2835,0x00000000,0);

            float iconY=navRect.top+43*s;
            stroke.setStrokeWidth(2.7f*s); stroke.setColor(tab==0?Color.WHITE:Color.rgb(189,181,188)); c.drawCircle(infoRect.centerX(),iconY,15*s,stroke);
            p.setColor(tab==0?Color.WHITE:Color.rgb(189,181,188)); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(21*s); c.drawText("i",infoRect.centerX(),iconY+7*s,p);
            p.setTextSize(19*s); c.drawText(tr("Информация","Information","Informations","信息","Información","معلومات","जानकारी","Informações","Information","情報"),infoRect.centerX(),navRect.bottom-22*s,p);
            stroke.setColor(tab==1?Color.WHITE:Color.rgb(189,181,188)); RectF b=new RectF(chatRect.centerX()-15*s,iconY-11*s,chatRect.centerX()+15*s,iconY+9*s); c.drawRect(b,stroke); Path tail=new Path(); tail.moveTo(chatRect.centerX()-6*s,iconY+9*s); tail.lineTo(chatRect.centerX()-11*s,iconY+16*s); tail.lineTo(chatRect.centerX()+1*s,iconY+9*s); c.drawPath(tail,stroke);
            p.setColor(tab==1?Color.WHITE:Color.rgb(189,181,188)); p.setTextSize(19*s); c.drawText(tr("Чат","Chat","Chat","聊天","Chat","دردشة","चैट","Chat","Chat","チャット"),chatRect.centerX(),navRect.bottom-22*s,p);

            p.setColor(Color.rgb(126,118,126)); p.setTypeface(Typeface.DEFAULT); p.setTextSize(17*s); c.drawText("Версия 0.5.0",w/2,h-18*s,p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        void drawRounded(Canvas c,RectF r,float radius,int fill,int line,float sw){
            p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawRoundRect(r,radius,radius,p);
            if(sw>0){ stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(sw); stroke.setColor(line); c.drawRoundRect(r,radius,radius,stroke); }
        }

        void drawGlobe(Canvas c,float x,float y,float r,int color){
            stroke.setColor(color); stroke.setStrokeWidth(2f); c.drawCircle(x,y,r,stroke); c.drawOval(new RectF(x-r*.45f,y-r,x+r*.45f,y+r),stroke); c.drawLine(x-r,y,x+r,y,stroke);
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=e.getX(), y=e.getY();
            if(langRect.contains(x,y)){ showLanguageDialog(); return true; }
            if(screen==0 && buttonRect.contains(x,y)){ screen=1; invalidate(); return true; }
            if(screen==1){
                if(infoRect.contains(x,y)){tab=0;invalidate();onTabChanged(tab);return true;}
                if(chatRect.contains(x,y)){tab=1;invalidate();onTabChanged(tab);return true;}
            }
            return true;
        }
    }
}
