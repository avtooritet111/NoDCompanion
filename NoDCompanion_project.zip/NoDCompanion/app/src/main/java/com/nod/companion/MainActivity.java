package com.nod.companion;

import android.app.AlertDialog;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.UUID;

public class MainActivity extends Activity {
    // После создания Firebase Realtime Database заменим это значение на ваш URL,
    // например: https://nod-companion-default-rtdb.europe-west1.firebasedatabase.app
    private static final String FIREBASE_URL = "https://nodcompanion-bc8cb-default-rtdb.europe-west1.firebasedatabase.app";
    private static final String FIREBASE_API_KEY = "AIzaSyCGDcPyyeZHGxk9TxWnBTTjRU6UxEi1ob4";
    private final Object firebaseAuthLock = new Object();
    private volatile String firebaseIdToken = "";
    private volatile long firebaseTokenExpiryMs = 0L;

    CompanionView view;
    SharedPreferences prefs;
    FrameLayout root;
    FrameLayout contentOverlay;
    Handler handler = new Handler(Looper.getMainLooper());
    Runnable refreshRunnable;
    boolean polling = false;
    ListView messageList;
    MessageAdapter messageAdapter;
    final ArrayList<ChatMessage> messages = new ArrayList<>();
    boolean keyboardVisible = false;
    int infoPage = 0; // 0 categories, 1 guides, 2 blood illusion

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(36,19,28));
        w.setNavigationBarColor(Color.rgb(9,7,12));
        prefs = getSharedPreferences("nod", MODE_PRIVATE);

        root = new FrameLayout(this);
        view = new CompanionView(this);
        root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        contentOverlay = new FrameLayout(this);
        FrameLayout.LayoutParams op = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        op.setMargins(dp(20), dp(105), dp(20), dp(145));
        root.addView(contentOverlay, op);
        contentOverlay.setVisibility(View.GONE);

        w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                boolean imeVisible = insets.isVisible(WindowInsets.Type.ime());
                int imeBottom = insets.getInsets(WindowInsets.Type.ime()).bottom;
                keyboardVisible = imeVisible;
                FrameLayout.LayoutParams cp = (FrameLayout.LayoutParams) contentOverlay.getLayoutParams();
                cp.bottomMargin = imeVisible ? imeBottom + dp(10) : dp(145);
                contentOverlay.setLayoutParams(cp);
                view.invalidate();
                return insets;
            });
        }

        setContentView(root);

        refreshRunnable = new Runnable() {
            @Override public void run() {
                if (!polling) return;
                fetchMessages();
                handler.postDelayed(this, 3000);
            }
        };
    }

    int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    boolean backendConfigured() {
        return FIREBASE_URL.startsWith("https://") && !FIREBASE_URL.contains("PASTE_");
    }

    GradientDrawable bg(int color, float radiusDp, int strokeColor, float strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), strokeColor);
        return d;
    }

    TextView tv(String text, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setTypeface(android.graphics.Typeface.DEFAULT, bold ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        return t;
    }

    EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(0xFF827A82);
        e.setTextColor(Color.WHITE);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setPadding(dp(16), 0, dp(16), 0);
        e.setBackground(bg(0xFF181219, 16, 0xFF44333E, 1));
        return e;
    }

    LinearLayout.LayoutParams lpMatch(int hDp) {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(hDp));
    }

    LinearLayout.LayoutParams lpMatchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    public void showLanguageDialog() {
        final String[] names = {"Русский","English","Français","简体中文","Español","العربية","हिन्दी","Português","Deutsch","日本語"};
        int checked = view.language;
        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle(view.tr("Выберите язык","Choose language","Choisissez la langue","选择语言","Elige idioma","اختر اللغة","भाषा चुनें","Escolha o idioma","Sprache wählen","言語を選択"))
                .setSingleChoiceItems(names, checked, (dialog, which) -> {
                    view.language = which;
                    prefs.edit().putInt("lang", which).apply();
                    view.invalidate();
                    if (view.screen == 1) {
                        if (view.tab == 1) showChatSection();
                        else if (infoPage == 2) showBloodIllusionArticle();
                        else if (infoPage == 1) showGuidesSection();
                        else showInfoSection();
                    }
                    dialog.dismiss();
                })
                .setNegativeButton(view.tr("ОТМЕНА","CANCEL","ANNULER","取消","CANCELAR","إلغاء","रद्द करें","CANCELAR","ABBRECHEN","キャンセル"), null)
                .create();
        dlg.setOnShowListener(d -> {
            if (dlg.getWindow() != null) dlg.getWindow().setBackgroundDrawable(new ColorDrawable(Color.rgb(68,68,68)));
            dlg.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.rgb(185,71,100));
        });
        dlg.show();
    }

    void onTabChanged(int tab) {
        contentOverlay.setVisibility(View.VISIBLE);
        if (tab == 1) {
            showChatSection();
        } else {
            stopPolling();
            hideKeyboard();
            showInfoSection();
        }
    }

    void showInfoSection() {
        infoPage = 0;
        contentOverlay.removeAllViews();

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        contentOverlay.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(8), dp(10), dp(8), dp(28));
        scroll.addView(wrap, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = tv(view.tr("Информация","Information","Informations","信息","Información","معلومات","जानकारी","Informações","Information","情報"), 25, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(18));
        wrap.addView(title, lpMatchWrap());

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        grid.setUseDefaultMargins(false);
        wrap.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        addMenuTile(grid, view.tr("Гайды","Guides","Guides","攻略","Guías","الأدلة","गाइड","Guias","Guides","攻略"),
                view.tr("Тактика и прохождение событий","Event tactics and walkthroughs","Tactiques et guides d’événements","活动战术与攻略","Tácticas y guías de eventos","تكتيكات وأدلة الفعاليات","इवेंट रणनीति और गाइड","Táticas e guias de eventos","Taktiken und Event-Guides","イベント攻略と戦術"),
                v -> showGuidesSection());
    }

    void addMenuTile(GridLayout grid, String title, String subtitle, View.OnClickListener click) {
        LinearLayout tile = new LinearLayout(this);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(16), dp(14), dp(16), dp(14));
        tile.setBackground(bg(0xD54B2835, 18, 0xFF6B3D4D, 1));
        tile.setMinimumHeight(dp(112));

        TextView t = tv(title, 19, Color.WHITE, true);
        tile.addView(t, lpMatchWrap());
        TextView sub = tv(subtitle, 13, 0xFFBEB5BC, false);
        sub.setPadding(0, dp(7), 0, 0);
        sub.setMaxLines(2);
        tile.addView(sub, lpMatchWrap());

        GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
        gp.width = 0;
        gp.height = ViewGroup.LayoutParams.WRAP_CONTENT;
        gp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);
        gp.setMargins(dp(5), dp(5), dp(5), dp(5));
        grid.addView(tile, gp);
        tile.setOnClickListener(click);
    }

    void showGuidesSection() {
        infoPage = 1;
        contentOverlay.removeAllViews();
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        contentOverlay.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(8), dp(4), dp(8), dp(28));
        scroll.addView(wrap, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView back = tv(view.tr("‹  Назад","‹  Back","‹  Retour","‹  返回","‹  Atrás","‹  رجوع","‹  वापस","‹  Voltar","‹  Zurück","‹  戻る"), 16, 0xFFD7B88A, true);
        back.setPadding(0, dp(4), 0, dp(10));
        back.setOnClickListener(v -> showInfoSection());
        wrap.addView(back, lpMatchWrap());

        TextView title = tv(view.tr("Гайды","Guides","Guides","攻略","Guías","الأدلة","गाइड","Guias","Guides","攻略"), 25, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(14));
        wrap.addView(title, lpMatchWrap());

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        grid.setAlignmentMode(GridLayout.ALIGN_BOUNDS);
        wrap.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        addMenuTile(grid, view.tr("Кровавая иллюзия","Blood Illusion","Illusion sanglante","血色幻境","Ilusión sangrienta","الوهم الدموي","रक्तिम भ्रम","Ilusão Sangrenta","Blutillusion","血の幻影"),
                view.tr("Гайд по прохождению события","Event walkthrough guide","Guide de l’événement","活动通关指南","Guía del evento","دليل اجتياز الفعالية","इवेंट गाइड","Guia do evento","Event-Leitfaden","イベント攻略ガイド"),
                v -> showBloodIllusionArticle());

        addMenuTile(grid, view.tr("Арена","Arena","Arène","竞技场","Arena","الساحة","एरीना","Arena","Arena","アリーナ"),
                view.tr("Раздел будет добавлен","Section coming soon","Section bientôt disponible","即将添加","Sección próximamente","سيتم إضافة القسم قريبًا","यह अनुभाग जल्द जोड़ा जाएगा","Seção em breve","Bereich folgt bald","近日追加予定"),
                v -> Toast.makeText(MainActivity.this, view.tr("Раздел скоро будет добавлен","Section coming soon","Section bientôt disponible","即将添加","Sección próximamente","سيتم إضافة القسم قريبًا","यह अनुभाग जल्द जोड़ा जाएगा","Seção em breve","Bereich folgt bald","近日追加予定"), Toast.LENGTH_SHORT).show());

        addMenuTile(grid, view.tr("Карл","Karl","Karl","卡尔","Karl","كارل","कार्ल","Karl","Karl","カール"),
                view.tr("Раздел будет добавлен","Section coming soon","Section bientôt disponible","即将添加","Sección próximamente","سيتم إضافة القسم قريبًا","यह अनुभाग जल्द जोड़ा जाएगा","Seção em breve","Bereich folgt bald","近日追加予定"),
                v -> Toast.makeText(MainActivity.this, view.tr("Раздел скоро будет добавлен","Section coming soon","Section bientôt disponible","即将添加","Sección próximamente","سيتم إضافة القسم قريبًا","यह अनुभाग जल्द जोड़ा जाएगा","Seção em breve","Bereich folgt bald","近日追加予定"), Toast.LENGTH_SHORT).show());
    }

    void addInfoHeading(LinearLayout wrap, String text) {
        TextView h = tv(text, 18, 0xFFD7B88A, true);
        h.setPadding(0, dp(18), 0, dp(6));
        wrap.addView(h, lpMatchWrap());
    }

    void addInfoParagraph(LinearLayout wrap, String text) {
        TextView t = tv(text, 16, 0xFFE8E1E5, false);
        t.setGravity(Gravity.TOP | Gravity.LEFT);
        t.setLineSpacing(0, 1.13f);
        t.setTextIsSelectable(true);
        t.setPadding(0, 0, 0, dp(12));
        wrap.addView(t, lpMatchWrap());
    }

    void showBloodIllusionArticle() {
        infoPage = 2;
        contentOverlay.removeAllViews();

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        contentOverlay.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(dp(8), dp(4), dp(8), dp(34));
        scroll.addView(wrap, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView back = tv(view.tr(
                "‹  Назад","‹  Back","‹  Retour","‹  返回","‹  Atrás","‹  رجوع","‹  वापस","‹  Voltar","‹  Zurück","‹  戻る"),
                16, 0xFFD7B88A, true);
        back.setPadding(0, dp(4), 0, dp(10));
        back.setOnClickListener(v -> showGuidesSection());
        wrap.addView(back, lpMatchWrap());

        TextView title = tv(view.tr(
                "Кровавая иллюзия","Blood Illusion","Illusion sanglante","血色幻境","Ilusión sangrienta","الوهم الدموي","रक्तिम भ्रम","Ilusão Sangrenta","Blutillusion","血の幻影"),
                27, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, dp(4), 0, dp(12));
        wrap.addView(title, lpMatchWrap());

        TextView intro = tv(view.tr(
                "Краткий гайд по прохождению события","Quick event walkthrough guide","Guide rapide de l’événement","活动快速攻略","Guía rápida del evento","دليل سريع للفعالية","इवेंट की संक्षिप्त गाइड","Guia rápido do evento","Kurzer Event-Leitfaden","イベント簡易攻略ガイド"),
                14, 0xFFA9A1A8, false);
        intro.setGravity(Gravity.CENTER);
        intro.setPadding(0, 0, 0, dp(14));
        wrap.addView(intro, lpMatchWrap());

        addInfoHeading(wrap, view.tr(
                "Старт","Start","Départ","开始","Inicio","البداية","शुरुआत","Início","Start","開始"));
        addInfoParagraph(wrap, view.tr(
                "• На самом первом уровне вы начнёте с выбора 5 героев.\n\n• Выбирайте героев так же, как для прохождения глав / PvP / арены / башен. Позже вы добавите ещё одну команду, а затем ещё одну на более высоких уровнях.\n\n• В самом верху находится шкала мобильности. Сначала она будет 0/25k. Каждый раз, когда вы выполняете задание, очки увеличиваются. Когда шкала заполнится, продолжить прохождение нельзя.",
                "• On the very first level, you start by selecting 5 heroes.\n\n• Choose heroes the same way you would for chapters / PvP / arena / towers. Later you will add a second team, and then a third team at higher levels.\n\n• The mobility bar is at the very top. It starts at 0/25k. Each time you complete a task, the points increase. Once the bar is full, you cannot continue.",
                "• Au tout premier niveau, vous commencez par choisir 5 héros.\n\n• Choisissez-les comme pour les chapitres / JcJ / l’arène / les tours. Plus tard, vous ajouterez une deuxième équipe, puis une troisième aux niveaux supérieurs.\n\n• La jauge de mobilité se trouve tout en haut. Elle commence à 0/25k. Chaque tâche accomplie augmente les points. Une fois la jauge pleine, vous ne pouvez plus continuer.",
                "• 在第一层，你将从选择 5 名英雄开始。\n\n• 像打章节 / PvP / 竞技场 / 高塔一样选择英雄。之后会增加第二支队伍，在更高层还会增加第三支队伍。\n\n• 顶部是机动值条，初始为 0/25k。每完成一个任务都会增加数值。数值满后就无法继续推进。",
                "• En el primer nivel comenzarás eligiendo 5 héroes.\n\n• Elige a los héroes igual que para capítulos / PvP / arena / torres. Más adelante añadirás un segundo equipo y, en niveles superiores, un tercero.\n\n• La barra de movilidad está arriba del todo. Empieza en 0/25k. Cada tarea completada aumenta los puntos. Cuando se llena, no puedes continuar.",
                "• في المستوى الأول تبدأ باختيار 5 أبطال.\n\n• اختر الأبطال كما تفعل للفصول / PvP / الساحة / الأبراج. لاحقًا ستضيف فريقًا ثانيًا ثم فريقًا ثالثًا في المستويات الأعلى.\n\n• شريط الحركة موجود في الأعلى. يبدأ من 0/25k، وكل مهمة ترفع النقاط. عندما يمتلئ الشريط لا يمكنك المتابعة.",
                "• सबसे पहले स्तर पर आप 5 नायकों का चयन करेंगे।\n\n• नायकों को वैसे ही चुनें जैसे अध्याय / PvP / एरीना / टॉवर के लिए चुनते हैं। बाद में दूसरी टीम और ऊँचे स्तरों पर तीसरी टीम भी जोड़ेंगे।\n\n• सबसे ऊपर मोबिलिटी बार है। यह 0/25k से शुरू होता है। हर कार्य पर अंक बढ़ते हैं। बार भर जाने पर आगे नहीं बढ़ सकते।",
                "• No primeiro nível, você começa escolhendo 5 heróis.\n\n• Escolha-os como faria para capítulos / PvP / arena / torres. Mais tarde você adicionará uma segunda equipe e, em níveis mais altos, uma terceira.\n\n• A barra de mobilidade fica no topo. Ela começa em 0/25k. Cada tarefa aumenta os pontos. Quando a barra enche, não é possível continuar.",
                "• Auf der allerersten Ebene wählst du zunächst 5 Helden aus.\n\n• Wähle die Helden wie für Kapitel / PvP / Arena / Türme. Später kommt ein zweites Team hinzu und auf höheren Ebenen noch ein drittes.\n\n• Ganz oben befindet sich die Mobilitätsleiste. Sie startet bei 0/25k. Jede Aufgabe erhöht die Punkte. Ist die Leiste voll, kannst du nicht weiter.",
                "• 最初の階層では、5人の英雄を選ぶところから始まります。\n\n• 章 / PvP / アリーナ / 塔を攻略するときと同じ感覚で英雄を選びます。後で2つ目のチーム、さらに高層では3つ目のチームも追加されます。\n\n• 画面上部にはモビリティゲージがあります。最初は0/25kです。課題をこなすたびに数値が増え、満タンになると先へ進めません。"));

        addInfoHeading(wrap, view.tr(
                "Как не заполнять мобильность / усталость","How to keep mobility / fatigue from filling up","Comment éviter de remplir la mobilité / fatigue","如何避免机动值 / 疲劳值涨满","Cómo evitar llenar la movilidad / fatiga","كيفية منع امتلاء الحركة / الإرهاق","मोबिलिटी / थकान को भरने से कैसे रोकें","Como evitar encher a mobilidade / fadiga","So verhinderst du, dass Mobilität / Ermüdung voll wird","モビリティ / 疲労を満タンにしない方法"));
        addInfoParagraph(wrap, view.tr(
                "1. Убедитесь, что ваши герои обладают хорошими характеристиками и оснащены снаряжением. Чем больше урона вы получите, тем сильнее увеличивается шкала — этого лучше избегать.",
                "1. Make sure your heroes have strong stats and proper gear. The more damage you take, the more the bar increases — avoid taking unnecessary damage.",
                "1. Assurez-vous que vos héros ont de bonnes statistiques et un bon équipement. Plus vous subissez de dégâts, plus la jauge augmente — évitez donc les dégâts inutiles.",
                "1. 确保英雄属性足够好并装备合适。受到的伤害越多，进度条增长越快，因此尽量避免不必要的伤害。",
                "1. Asegúrate de que tus héroes tengan buenas estadísticas y equipo. Cuanto más daño recibas, más aumentará la barra; evita el daño innecesario.",
                "1. تأكد من أن أبطالك يمتلكون خصائص جيدة ومعدات مناسبة. كلما تلقيت ضررًا أكثر ارتفع الشريط أكثر، لذا تجنب الضرر غير الضروري.",
                "1. सुनिश्चित करें कि आपके नायकों के आँकड़े अच्छे हों और वे सही गियर से लैस हों। जितना अधिक नुकसान लेंगे, बार उतना ही तेज़ बढ़ेगा—अनावश्यक नुकसान से बचें।",
                "1. Certifique-se de que seus heróis tenham bons atributos e equipamentos. Quanto mais dano você sofrer, mais a barra aumenta — evite dano desnecessário.",
                "1. Stelle sicher, dass deine Helden gute Werte und passende Ausrüstung haben. Je mehr Schaden du nimmst, desto stärker steigt die Leiste — vermeide unnötigen Schaden.",
                "1. 英雄の能力値と装備を十分に整えてください。受けるダメージが多いほどゲージが増えるため、不要な被ダメージは避けましょう。"));
        addInfoParagraph(wrap, view.tr(
                "2. Избегайте любых ворот испытаний, кроме СИНИХ обычных испытаний. Так вы получите меньше очков усталости.",
                "2. Avoid all Trial Gates except the BLUE normal trial gates. This keeps fatigue gain lower.",
                "2. Évitez toutes les portes d’épreuve sauf les portes BLEUES normales. Vous gagnerez ainsi moins de fatigue.",
                "2. 除了蓝色普通试炼门之外，尽量避开其他试炼门。这样获得的疲劳值更少。",
                "2. Evita todas las puertas de prueba excepto las puertas AZULES normales. Así ganarás menos fatiga.",
                "2. تجنب كل بوابات الاختبار باستثناء البوابات الزرقاء العادية. بهذه الطريقة ستحصل على نقاط إرهاق أقل.",
                "2. नीले सामान्य ट्रायल गेट्स के अलावा बाकी सभी ट्रायल गेट्स से बचें। इससे थकान कम बढ़ेगी।",
                "2. Evite todos os portões de desafio, exceto os portões AZUIS normais. Assim você ganha menos fadiga.",
                "2. Meide alle Prüfungs-Tore außer den normalen BLAUEN Prüfungen. So sammelst du weniger Ermüdung.",
                "2. 青色の通常試練ゲート以外の試練ゲートは避けましょう。疲労ポイントの増加を抑えられます。"));
        addInfoParagraph(wrap, view.tr(
                "3. Избегайте ФИОЛЕТОВЫХ ворот вызова, которые предлагают сделку. В лучшем случае это может дать +8 тысяч, а другие испытания внутри могут дать намного больше очков усталости, чем обычно.",
                "3. Avoid the PURPLE Challenge Gates that offer a deal. Even the best outcome can add +8,000, and the other trials inside may add far more fatigue than usual.",
                "3. Évitez les portes de défi VIOLETTES qui proposent un marché. Même le meilleur résultat peut ajouter +8 000, et les autres épreuves peuvent donner bien plus de fatigue que d’habitude.",
                "3. 避开会提供交易的紫色挑战门。即使最好的结果也可能增加 8,000 点，而其中其他试炼带来的疲劳值可能远高于平常。",
                "3. Evita las puertas MORADAS de desafío que ofrecen un trato. Incluso el mejor resultado puede sumar +8.000, y las otras pruebas pueden añadir mucha más fatiga de lo normal.",
                "3. تجنب بوابات التحدي البنفسجية التي تعرض صفقة. حتى أفضل نتيجة قد تضيف +8000، وقد تضيف الاختبارات الأخرى داخلها إرهاقًا أكبر بكثير من المعتاد.",
                "3. बैंगनी चैलेंज गेट्स से बचें जो सौदा पेश करते हैं। सबसे अच्छे नतीजे में भी +8,000 बढ़ सकता है, और अंदर के दूसरे ट्रायल सामान्य से बहुत अधिक थकान दे सकते हैं।",
                "3. Evite os portões ROXOS de desafio que oferecem uma troca. Mesmo o melhor resultado pode adicionar +8.000, e os outros desafios podem gerar muito mais fadiga que o normal.",
                "3. Meide die VIOLETTEN Herausforderungs-Tore mit einem Angebot. Selbst das beste Ergebnis kann +8.000 bringen, und andere Prüfungen darin können deutlich mehr Ermüdung verursachen als üblich.",
                "3. 取引を提示する紫色のチャレンジゲートは避けましょう。最良でも+8,000増えることがあり、中の別試練では通常より大幅に疲労が増える場合があります。"));
        addInfoParagraph(wrap, view.tr(
                "4. Примерно каждые 4 уровня появляются ЗЕЛЁНЫЕ врата — «Спокойствие». Всегда выбирайте их: они снижают усталость на 8 000. На более высоких уровнях усталость растёт быстрее и придётся использовать 3 команды героев — всего 15 героев с хорошо распределённым снаряжением, танками и лечением, если это возможно.",
                "4. About every 4 levels, GREEN gates called “Tranquility” appear. Always choose them: they reduce fatigue by 8,000. At higher levels fatigue rises faster, and you will need 3 hero teams — 15 heroes total, with gear distributed well and tanks/healers where possible.",
                "4. Environ tous les 4 niveaux, des portes VERTES appelées « Tranquillité » apparaissent. Choisissez-les toujours : elles réduisent la fatigue de 8 000. Aux niveaux élevés, la fatigue monte plus vite et vous aurez besoin de 3 équipes, soit 15 héros, avec un équipement bien réparti et si possible des tanks et des soigneurs.",
                "4. 大约每 4 层会出现绿色的“宁静”门。一定要选择它们：可降低 8,000 点疲劳。层数越高，疲劳增长越快，需要使用 3 支英雄队伍——共 15 名英雄，并合理分配装备，尽量安排坦克和治疗。",
                "4. Aproximadamente cada 4 niveles aparecen puertas VERDES llamadas «Tranquilidad». Elígelas siempre: reducen la fatiga en 8.000. En niveles altos la fatiga sube más rápido y necesitarás 3 equipos, 15 héroes en total, con el equipo bien repartido y tanques/sanadores si es posible.",
                "4. تظهر تقريبًا كل 4 مستويات بوابات خضراء تسمى «السكينة». اخترها دائمًا لأنها تقلل الإرهاق بمقدار 8000. في المستويات الأعلى يرتفع الإرهاق أسرع وستحتاج إلى 3 فرق، أي 15 بطلًا، مع توزيع جيد للمعدات ووجود دبابات ومعالجين إن أمكن.",
                "4. लगभग हर 4 स्तर पर हरे “Tranquility” गेट दिखाई देते हैं। इन्हें हमेशा चुनें: ये थकान 8,000 कम करते हैं। ऊँचे स्तरों पर थकान तेज़ बढ़ती है और आपको 3 टीमों—कुल 15 नायकों—की जरूरत होगी, जिनमें गियर सही बाँटा गया हो और संभव हो तो टैंक/हीलर हों।",
                "4. Aproximadamente a cada 4 níveis aparecem portões VERDES chamados “Tranquilidade”. Escolha-os sempre: eles reduzem a fadiga em 8.000. Em níveis altos, a fadiga sobe mais rápido e você precisará de 3 equipes — 15 heróis no total — com equipamentos bem distribuídos e tanques/curadores quando possível.",
                "4. Etwa alle 4 Ebenen erscheinen GRÜNE Tore namens „Ruhe“. Wähle sie immer: Sie senken die Ermüdung um 8.000. Auf höheren Ebenen steigt die Ermüdung schneller und du brauchst 3 Heldenteams — insgesamt 15 Helden — mit gut verteilter Ausrüstung sowie möglichst Tanks und Heilern.",
                "4. 約4階ごとに緑色の「安らぎ」ゲートが出現します。必ず選びましょう。疲労を8,000減らせます。高層では疲労が増えやすくなり、3チーム＝合計15人の英雄が必要です。装備をうまく分配し、可能ならタンクとヒーラーも用意してください。"));
        addInfoParagraph(wrap, view.tr(
                "5. Поскольку «Спокойствие» появляется примерно раз в 4 уровня, используйте также СИНИЕ врата «Благословение». Это бесплатный уровень, который увеличивает атрибуты для следующих двух испытаний и уменьшает количество уровней, которые нужно пройти до следующего «Спокойствия».",
                "5. Because “Tranquility” appears about every 4 levels, also use the BLUE “Blessing” gates. They are a free level that boosts attributes for the next two trials and reduces how many levels you need to clear before “Tranquility” can appear again.",
                "5. Comme « Tranquillité » apparaît environ tous les 4 niveaux, utilisez aussi les portes BLEUES « Bénédiction ». C’est un niveau gratuit qui augmente les attributs pour les deux prochaines épreuves et réduit le nombre de niveaux à passer avant la prochaine « Tranquillité ».",
                "5. 因为“宁静”大约每 4 层出现一次，也要利用蓝色“祝福”门。这是一个免费层，可提升接下来两次试炼的属性，并减少再次遇到“宁静”前需要通过的层数。",
                "5. Como «Tranquilidad» aparece aproximadamente cada 4 niveles, usa también las puertas AZULES de «Bendición». Es un nivel gratuito que aumenta los atributos para las dos pruebas siguientes y reduce los niveles necesarios hasta que vuelva a aparecer «Tranquilidad».",
                "5. بما أن «السكينة» تظهر تقريبًا كل 4 مستويات، استخدم أيضًا بوابات «البركة» الزرقاء. إنها مستوى مجاني يزيد السمات للاختبارين التاليين ويقلل عدد المستويات المطلوبة قبل ظهور «السكينة» مجددًا.",
                "5. क्योंकि “Tranquility” लगभग हर 4 स्तर पर आता है, नीले “Blessing” गेट भी लें। यह एक मुफ्त स्तर है जो अगले दो ट्रायल के लिए आँकड़े बढ़ाता है और अगली “Tranquility” तक जाने वाले स्तरों की संख्या कम करता है।",
                "5. Como “Tranquilidade” aparece aproximadamente a cada 4 níveis, use também os portões AZUIS de “Bênção”. É um nível gratuito que aumenta os atributos nas próximas duas provas e reduz quantos níveis você precisa passar até a próxima “Tranquilidade”.",
                "5. Da „Ruhe“ ungefähr alle 4 Ebenen erscheint, nutze auch die BLAUEN „Segen“-Tore. Sie sind eine kostenlose Ebene, erhöhen die Attribute für die nächsten zwei Prüfungen und verkürzen den Weg bis zur nächsten „Ruhe“.",
                "5. 「安らぎ」は約4階ごとに出るため、青色の「祝福」ゲートも利用しましょう。無料で進める階層で、次の2つの試練の能力値を強化し、次の「安らぎ」までに必要な階層数も減らせます。"));
        addInfoParagraph(wrap, view.tr(
                "6. Если вы не видите нужные врата «Вызов» / «Благословение» / «Спокойствие», выйдите из окна выбора врат и нажмите на башню ещё раз. Каждый раз появляется случайный набор ворот. Нажмите на пустое место и снова на башню, чтобы обновить выбор.",
                "6. If you do not see the gate you want — “Challenge” / “Blessing” / “Tranquility” — leave the gate-selection window and tap the tower again. Each tap gives a random set of gates. Tap an empty area, then tap the tower again to reroll the choices.",
                "6. Si vous ne voyez pas la porte souhaitée — « Défi » / « Bénédiction » / « Tranquillité » — quittez l’écran de sélection puis touchez de nouveau la tour. Chaque fois, un choix aléatoire apparaît. Touchez une zone vide puis la tour pour relancer les choix.",
                "6. 如果没有看到想要的“挑战” / “祝福” / “宁静”门，就退出选门界面并再次点击高塔。每次都会随机出现一组门。点击空白处，再点击高塔即可刷新选择。",
                "6. Si no ves la puerta que necesitas — «Desafío» / «Bendición» / «Tranquilidad» — sal de la selección y toca la torre otra vez. Cada vez aparece un conjunto aleatorio. Toca una zona vacía y vuelve a tocar la torre para cambiar las opciones.",
                "6. إذا لم ترَ البوابة المطلوبة — «التحدي» / «البركة» / «السكينة» — اخرج من نافذة اختيار البوابات واضغط على البرج مرة أخرى. في كل مرة تحصل على مجموعة عشوائية. اضغط على مساحة فارغة ثم على البرج لتحديث الخيارات.",
                "6. अगर मनचाहा “Challenge” / “Blessing” / “Tranquility” गेट न दिखे, गेट चयन विंडो से बाहर निकलें और टॉवर पर फिर टैप करें। हर बार गेट्स का यादृच्छिक सेट मिलेगा। खाली जगह पर टैप करें, फिर टॉवर पर टैप करके विकल्प बदलें।",
                "6. Se não aparecer o portão desejado — “Desafio” / “Bênção” / “Tranquilidade” — saia da tela de seleção e toque na torre novamente. A cada toque aparece um conjunto aleatório. Toque numa área vazia e depois na torre para renovar as opções.",
                "6. Wenn das gewünschte Tor — „Herausforderung“ / „Segen“ / „Ruhe“ — nicht erscheint, verlasse die Torauswahl und tippe erneut auf den Turm. Jedes Mal erscheint eine zufällige Auswahl. Tippe auf eine freie Stelle und dann wieder auf den Turm, um neu zu würfeln.",
                "6. 欲しい「チャレンジ」/「祝福」/「安らぎ」ゲートが見えない場合は、ゲート選択画面を閉じて塔をもう一度タップしてください。毎回ランダムなゲートが表示されます。空いている場所をタップしてから再び塔をタップすると選択肢を更新できます。"));

        addInfoHeading(wrap, view.tr(
                "Если шкала уже заполнена","If the bar is already full","Si la jauge est déjà pleine","如果进度条已经满了","Si la barra ya está llena","إذا امتلأ الشريط بالفعل","अगर बार पहले ही भर चुका है","Se a barra já estiver cheia","Wenn die Leiste bereits voll ist","ゲージがすでに満タンの場合"));
        addInfoParagraph(wrap, view.tr(
                "Если очки мобильности / усталости исчерпаны, бросьте вызов ещё раз через нижнюю правую кнопку. Вы начнёте с последнего пройденного уровня, заканчивающегося на 0. Например, если вы прошли 109 уровней и заполнили мобильность, начнёте с испытания 101.",
                "If your mobility / fatigue points are exhausted, start the challenge again using the lower-right button. You will restart from the last cleared block of ten. For example, if you cleared level 109 and filled the bar, you will restart from trial 101.",
                "Si vos points de mobilité / fatigue sont épuisés, relancez le défi avec le bouton en bas à droite. Vous repartez du dernier palier de dix terminé. Par exemple, après le niveau 109 avec la jauge pleine, vous recommencez à l’épreuve 101.",
                "如果机动值 / 疲劳值已经耗尽，请使用右下角按钮重新挑战。你会从最近一个已通过的整十段开始。例如通过 109 层并把进度条刷满后，会从 101 层重新开始。",
                "Si se agotan los puntos de movilidad / fatiga, vuelve a iniciar el desafío con el botón inferior derecho. Empezarás desde el último bloque de diez superado. Por ejemplo, si llegaste al 109 y llenaste la barra, empezarás desde la prueba 101.",
                "إذا نفدت نقاط الحركة / الإرهاق، ابدأ التحدي مرة أخرى من الزر السفلي الأيمن. ستبدأ من آخر مجموعة من عشرة مستويات اجتزتها. مثال: إذا وصلت إلى 109 وامتلأ الشريط فستبدأ من الاختبار 101.",
                "अगर मोबिलिटी / थकान अंक समाप्त हो जाएँ, नीचे-दाएँ बटन से चुनौती फिर शुरू करें। आप पिछली पूरी की गई दस-स्तरीय सीमा से शुरू करेंगे। उदाहरण: 109 तक पहुँचकर बार भर गया तो 101 से शुरू होगा।",
                "Se os pontos de mobilidade / fadiga acabarem, inicie o desafio novamente pelo botão inferior direito. Você voltará ao último bloco de dez concluído. Exemplo: se chegou ao 109 e encheu a barra, recomeçará no desafio 101.",
                "Wenn deine Mobilitäts-/Ermüdungspunkte aufgebraucht sind, starte die Herausforderung über die Schaltfläche unten rechts neu. Du beginnst beim letzten abgeschlossenen Zehnerblock. Beispiel: Nach Ebene 109 mit voller Leiste startest du bei Prüfung 101.",
                "モビリティ / 疲労ポイントが尽きたら、右下のボタンから再挑戦してください。最後に到達した10階単位の区切りから再開します。例：109階まで進んでゲージが満タンになった場合、101階から再開します。"));

        addInfoHeading(wrap, view.tr(
                "Можно ли повторять испытания на максимальном уровне?","Can I repeat trials after reaching the maximum level?","Puis-je répéter les épreuves au niveau maximal ?","到达最高层后还能重复试炼吗？","¿Puedo repetir pruebas al llegar al nivel máximo?","هل يمكن تكرار الاختبارات بعد بلوغ المستوى الأقصى؟","अधिकतम स्तर पर पहुँचने के बाद ट्रायल दोहरा सकते हैं?","Posso repetir desafios depois do nível máximo?","Kann ich Prüfungen nach Erreichen der Maximalebene wiederholen?","最大階層到達後に試練を繰り返せますか？"));
        addInfoParagraph(wrap, view.tr(
                "Нет. Награды за это не выдаются — используются только попытки сброса на текущее время события.",
                "No. You do not receive rewards for repeating them; it only consumes reset attempts for the current event period.",
                "Non. Vous ne recevez aucune récompense ; cela consomme seulement des tentatives de réinitialisation pour la période actuelle de l’événement.",
                "不能。重复试炼不会获得奖励，只会消耗当前活动期间的重置次数。",
                "No. No obtienes recompensas; solo consumes intentos de reinicio del periodo actual del evento.",
                "لا. لن تحصل على مكافآت، وسيتم فقط استهلاك محاولات إعادة الضبط خلال فترة الفعالية الحالية.",
                "नहीं। दोहराने पर कोई पुरस्कार नहीं मिलता; केवल मौजूदा इवेंट अवधि की रीसेट कोशिशें खर्च होती हैं।",
                "Não. Você não recebe recompensas; apenas gasta tentativas de reinício do período atual do evento.",
                "Nein. Dafür gibt es keine Belohnungen; es werden lediglich Reset-Versuche des aktuellen Event-Zeitraums verbraucht.",
                "いいえ。繰り返しても報酬は得られず、現在のイベント期間のリセット回数だけを消費します。"));

        addInfoHeading(wrap, view.tr(
                "Алтарь очищения","Purification Altar","Autel de purification","净化祭坛","Altar de purificación","مذبح التطهير","शुद्धिकरण वेदी","Altar de Purificação","Altar der Reinigung","浄化の祭壇"));
        addInfoParagraph(wrap, view.tr(
                "Алтарь очищения снижает Кровавые очки на 8 000. В игре он описан как таинственный алтарь с успокаивающей аурой.",
                "The Purification Altar reduces Blood Points by 8,000. In the game it is described as a mysterious altar with a calming aura.",
                "L’Autel de purification réduit les Points sanglants de 8 000. Le jeu le décrit comme un autel mystérieux à l’aura apaisante.",
                "净化祭坛可减少 8,000 点血色点数。游戏中将其描述为散发宁静气息的神秘祭坛。",
                "El Altar de purificación reduce los Puntos de sangre en 8.000. El juego lo describe como un altar misterioso con un aura tranquilizadora.",
                "يقلل مذبح التطهير نقاط الدم بمقدار 8000. ويصفه اللعب كمذبح غامض يشع بهالة مهدئة.",
                "शुद्धिकरण वेदी Blood Points को 8,000 कम करती है। खेल में इसे शांत करने वाली आभा वाली रहस्यमय वेदी बताया गया है।",
                "O Altar de Purificação reduz os Pontos de Sangue em 8.000. No jogo, ele é descrito como um altar misterioso com uma aura calmante.",
                "Der Altar der Reinigung senkt Blutpunkte um 8.000. Im Spiel wird er als geheimnisvoller Altar mit beruhigender Aura beschrieben.",
                "浄化の祭壇は血のポイントを8,000減らします。ゲーム内では、心を落ち着かせるオーラを放つ謎めいた祭壇と説明されています。"));

        addInfoHeading(wrap, view.tr(
                "Дополнительный совет","Extra tip","Conseil supplémentaire","额外提示","Consejo adicional","نصيحة إضافية","अतिरिक्त सुझाव","Dica extra","Zusätzlicher Tipp","追加のヒント"));
        addInfoParagraph(wrap, view.tr(
                "Над башней Алого ордена находится «Алая луна». Она накапливает опыт для этого события, а также даёт коробки с рунами героев.",
                "Above the Crimson Order tower is the “Crimson Moon”. It accumulates experience for this event and also grants boxes containing hero runes.",
                "Au-dessus de la tour de l’Ordre écarlate se trouve la « Lune écarlate ». Elle accumule de l’expérience pour cet événement et donne aussi des boîtes contenant des runes de héros.",
                "猩红教团高塔上方有“猩红之月”。它会为该活动积累经验，并提供装有英雄符文的箱子。",
                "Sobre la torre de la Orden Carmesí está la «Luna Carmesí». Acumula experiencia para el evento y también otorga cajas con runas de héroe.",
                "فوق برج النظام القرمزي توجد «القمر القرمزي». وهي تجمع خبرة لهذه الفعالية وتمنح أيضًا صناديق تحتوي على رونات الأبطال.",
                "Crimson Order टॉवर के ऊपर “Crimson Moon” है। यह इवेंट के लिए अनुभव जमा करती है और हीरो रून वाले बॉक्स भी देती है।",
                "Acima da torre da Ordem Carmesim fica a “Lua Carmesim”. Ela acumula experiência para o evento e também concede caixas com runas de herói.",
                "Über dem Turm des Karmesinordens befindet sich der „Karmesinmond“. Er sammelt Erfahrung für dieses Event und gewährt außerdem Kisten mit Heldenrunen.",
                "深紅の騎士団の塔の上には「深紅の月」があります。このイベント用の経験値を蓄積し、英雄ルーン入りの箱も獲得できます。"));

        addInfoHeading(wrap, view.tr(
                "Элементы события","Event elements","Éléments de l’événement","活动元素","Elementos del evento","عناصر الفعالية","इवेंट के तत्व","Elementos do evento","Event-Elemente","イベント要素"));
        addInfoParagraph(wrap, view.tr(
                "На экране события также отображаются: Кровавая луна, Кровавая башня, Кровавая метка, Кровавый контракт, Кровавый подарок и Кровавая ода.",
                "The event screen also shows: Blood Moon, Blood Tower, Blood Mark, Blood Contract, Blood Gift, and Blood Ode.",
                "L’écran de l’événement affiche également : Lune sanglante, Tour sanglante, Marque sanglante, Contrat sanglant, Cadeau sanglant et Ode sanglante.",
                "活动界面还会显示：血月、血塔、血之印记、血之契约、血之礼物和血之颂歌。",
                "La pantalla del evento también muestra: Luna Sangrienta, Torre Sangrienta, Marca Sangrienta, Contrato Sangriento, Regalo Sangriento y Oda Sangrienta.",
                "تعرض شاشة الفعالية أيضًا: القمر الدموي، البرج الدموي، العلامة الدموية، العقد الدموي، الهدية الدموية، والقصيدة الدموية.",
                "इवेंट स्क्रीन पर ये भी दिखते हैं: Blood Moon, Blood Tower, Blood Mark, Blood Contract, Blood Gift और Blood Ode।",
                "A tela do evento também mostra: Lua Sangrenta, Torre Sangrenta, Marca Sangrenta, Contrato Sangrento, Presente Sangrento e Ode Sangrenta.",
                "Auf dem Event-Bildschirm werden außerdem angezeigt: Blutmond, Blutturm, Blutmal, Blutvertrag, Blutgeschenk und Blutode.",
                "イベント画面には、血の月、血の塔、血の印、血の契約、血の贈り物、血の頌歌も表示されます。"));
    }

    void showChatSection() {
        contentOverlay.removeAllViews();
        if (!prefs.getBoolean("registered", false)) {
            stopPolling();
            showRegistration();
        } else {
            showChat();
            startPolling();
        }
    }

    void showRegistration() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        contentOverlay.addView(scroll, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setGravity(Gravity.CENTER_HORIZONTAL);
        wrap.setPadding(dp(8), dp(18), dp(8), dp(8));
        scroll.addView(wrap, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = tv(view.tr("Регистрация в чате","Chat registration","Inscription au chat","聊天注册","Registro del chat","تسجيل الدردشة","चैट पंजीकरण","Registro no chat","Chat-Registrierung","チャット登録"), 25, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        wrap.addView(title, lpMatchWrap());

        TextView sub = tv(view.tr(
                "Заполните данные один раз. Они сохранятся на этом телефоне.",
                "Enter your details once. They will stay saved on this phone.",
                "Saisissez vos données une fois. Elles resteront enregistrées sur ce téléphone.",
                "只需填写一次，信息将保存在此手机上。",
                "Introduce tus datos una vez. Se guardarán en este teléfono.",
                "أدخل بياناتك مرة واحدة. ستبقى محفوظة على هذا الهاتف.",
                "जानकारी एक बार भरें। यह इस फ़ोन पर सहेजी रहेगी।",
                "Preencha seus dados uma vez. Eles ficarão salvos neste telefone.",
                "Daten einmal eingeben. Sie bleiben auf diesem Telefon gespeichert.",
                "一度入力すれば、この端末に保存されます。"), 14, 0xFFA9A1A8, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(dp(18), dp(8), dp(18), dp(22));
        wrap.addView(sub, lpMatchWrap());

        EditText server = edit(view.tr("Номер сервера","Server number","Numéro du serveur","服务器编号","Número de servidor","رقم الخادم","सर्वर नंबर","Número do servidor","Servernummer","サーバー番号"));
        server.setInputType(InputType.TYPE_CLASS_NUMBER);
        wrap.addView(server, lpMatch(56));

        Space s1 = new Space(this); wrap.addView(s1, new LinearLayout.LayoutParams(1, dp(12)));

        EditText alliance = edit(view.tr("Альянс — 3 буквы, например WEE","Alliance — 3 letters, e.g. WEE","Alliance — 3 lettres, ex. WEE","联盟 — 3 个字母，例如 WEE","Alianza — 3 letras, p. ej. WEE","التحالف — 3 أحرف، مثال WEE","गठबंधन — 3 अक्षर, जैसे WEE","Aliança — 3 letras, ex. WEE","Allianz — 3 Buchstaben, z. B. WEE","同盟 — 3文字、例 WEE"));
        alliance.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
        alliance.setFilters(new InputFilter[]{new InputFilter.LengthFilter(3)});
        final boolean[] allianceEditing = {false};
        alliance.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int st, int before, int count) {}
            @Override public void afterTextChanged(Editable e) {
                if (allianceEditing[0]) return;
                String clean = e.toString().toUpperCase(Locale.US).replaceAll("[^A-Z]", "");
                if (clean.length() > 3) clean = clean.substring(0,3);
                if (!clean.equals(e.toString())) {
                    allianceEditing[0] = true;
                    alliance.setText(clean);
                    alliance.setSelection(clean.length());
                    allianceEditing[0] = false;
                }
            }
        });
        wrap.addView(alliance, lpMatch(56));

        Space s2 = new Space(this); wrap.addView(s2, new LinearLayout.LayoutParams(1, dp(12)));

        EditText nick = edit(view.tr("Никнейм","Nickname","Pseudo","昵称","Apodo","الاسم المستعار","उपनाम","Apelido","Nickname","ニックネーム"));
        nick.setFilters(new InputFilter[]{new InputFilter.LengthFilter(24)});
        wrap.addView(nick, lpMatch(56));

        Space s3 = new Space(this); wrap.addView(s3, new LinearLayout.LayoutParams(1, dp(18)));

        Button register = new Button(this);
        register.setAllCaps(false);
        register.setText(view.tr("Зарегистрироваться","Register","S'inscrire","注册","Registrarse","تسجيل","रजिस्टर करें","Registrar","Registrieren","登録"));
        register.setTextColor(Color.WHITE);
        register.setTextSize(16);
        register.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        register.setBackground(bg(0xFFB94764, 18, 0, 0));
        wrap.addView(register, lpMatch(58));

        TextView error = tv("", 13, 0xFFFF7B8F, false);
        error.setGravity(Gravity.CENTER);
        error.setPadding(dp(8), dp(12), dp(8), 0);
        wrap.addView(error, lpMatchWrap());

        register.setOnClickListener(v -> {
            String sv = server.getText().toString().trim();
            String al = alliance.getText().toString().trim().toUpperCase(Locale.US);
            String ni = nick.getText().toString().trim();
            if (sv.length() == 0 || !sv.matches("[0-9]+")) {
                error.setText(view.tr("Введите номер сервера.","Enter the server number.","Entrez le numéro du serveur.","请输入服务器编号。","Introduce el número del servidor.","أدخل رقم الخادم.","सर्वर नंबर दर्ज करें।","Digite o número do servidor.","Servernummer eingeben.","サーバー番号を入力してください。"));
                return;
            }
            if (!al.matches("[A-Z]{3}")) {
                error.setText(view.tr("Альянс должен состоять ровно из 3 латинских букв.","Alliance must be exactly 3 Latin letters.","L'alliance doit contenir exactement 3 lettres latines.","联盟必须正好是 3 个英文字母。","La alianza debe tener exactamente 3 letras latinas.","يجب أن يتكون التحالف من 3 أحرف لاتينية بالضبط.","गठबंधन में ठीक 3 लैटिन अक्षर होने चाहिए।","A aliança deve ter exatamente 3 letras latinas.","Die Allianz muss genau 3 lateinische Buchstaben haben.","同盟は英字3文字ちょうどにしてください。"));
                return;
            }
            if (ni.length() < 2) {
                error.setText(view.tr("Введите никнейм.","Enter a nickname.","Entrez un pseudo.","请输入昵称。","Introduce un apodo.","أدخل اسماً مستعاراً.","उपनाम दर्ज करें।","Digite um apelido.","Nickname eingeben.","ニックネームを入力してください。"));
                return;
            }
            String userId = prefs.getString("user_id", "");
            if (userId.length() == 0) userId = UUID.randomUUID().toString();
            prefs.edit()
                    .putBoolean("registered", true)
                    .putString("server", sv)
                    .putString("alliance", al)
                    .putString("nick", ni)
                    .putString("user_id", userId)
                    .apply();
            hideKeyboard();
            new Thread(() -> {
                try { ensureFirebaseProfile(); } catch (Exception ignored) {}
            }).start();
            showChatSection();
        });
    }

    void showChat() {
        FrameLayout panel = new FrameLayout(this);
        contentOverlay.addView(panel, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        panel.addView(col, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(8), dp(4), dp(8), dp(10));
        TextView title = tv(view.tr("Общий чат","Global chat","Chat global","公共聊天","Chat global","الدردشة العامة","सार्वजनिक चैट","Chat geral","Allgemeiner Chat","全体チャット"), 22, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        header.addView(title, lpMatchWrap());
        String identity = "[" + prefs.getString("server", "?") + "] [" + prefs.getString("alliance", "???") + "] " + prefs.getString("nick", "");
        TextView me = tv(identity, 13, 0xFFD7B88A, false);
        me.setGravity(Gravity.CENTER);
        header.addView(me, lpMatchWrap());
        col.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        if (!backendConfigured()) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setPadding(dp(22), dp(22), dp(22), dp(22));
            card.setBackground(bg(0xD8231820, 22, 0xFF493642, 1));
            TextView t = tv(view.tr("Чат почти готов","Chat is almost ready","Le chat est presque prêt","聊天即将就绪","El chat casi está listo","الدردشة جاهزة تقريباً","चैट लगभग तैयार है","O chat está quase pronto","Chat ist fast fertig","チャットはほぼ準備完了"), 22, Color.WHITE, true);
            t.setGravity(Gravity.CENTER); card.addView(t, lpMatchWrap());
            TextView d = tv(view.tr(
                    "Регистрация уже работает и сохранена. Осталось подключить онлайн-базу Firebase — после этого сообщения будут общими для всех игроков.",
                    "Registration already works and is saved. We only need to connect Firebase; then messages will be shared by all players.",
                    "L'inscription fonctionne déjà et est enregistrée. Il reste à connecter Firebase pour partager les messages entre tous les joueurs.",
                    "注册已可用并已保存。只需连接 Firebase，所有玩家即可共享消息。",
                    "El registro ya funciona y se guarda. Solo falta conectar Firebase para que los mensajes sean compartidos por todos.",
                    "التسجيل يعمل ويتم حفظه. بقي فقط ربط Firebase لتصبح الرسائل مشتركة بين جميع اللاعبين.",
                    "पंजीकरण काम कर रहा है और सहेजा जाता है। अब केवल Firebase जोड़ना है ताकि सभी खिलाड़ी एक ही चैट देखें।",
                    "O registro já funciona e fica salvo. Só falta conectar o Firebase para que as mensagens sejam compartilhadas entre todos.",
                    "Die Registrierung funktioniert bereits und bleibt gespeichert. Jetzt muss nur noch Firebase verbunden werden, damit alle Spieler denselben Chat sehen.",
                    "登録はすでに動作し保存されます。あとは Firebase を接続すれば、全プレイヤーで同じメッセージを共有できます。"), 15, 0xFFBEB5BC, false);
            d.setGravity(Gravity.CENTER); d.setPadding(0, dp(12), 0, 0); card.addView(d, lpMatchWrap());
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            cp.setMargins(dp(6), dp(36), dp(6), 0);
            col.addView(card, cp);
            return;
        }

        messageList = new ListView(this);
        messageList.setDivider(new ColorDrawable(Color.TRANSPARENT));
        messageList.setDividerHeight(dp(7));
        messageList.setSelector(new ColorDrawable(Color.TRANSPARENT));
        messageList.setCacheColorHint(Color.TRANSPARENT);
        messageList.setBackgroundColor(Color.TRANSPARENT);
        messageAdapter = new MessageAdapter(this, messages);
        messageList.setAdapter(messageAdapter);
        LinearLayout.LayoutParams listLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        col.addView(messageList, listLp);

        LinearLayout sendBar = new LinearLayout(this);
        sendBar.setOrientation(LinearLayout.HORIZONTAL);
        sendBar.setGravity(Gravity.CENTER_VERTICAL);
        sendBar.setPadding(0, dp(8), 0, 0);
        EditText input = edit(view.tr("Сообщение…","Message…","Message…","消息…","Mensaje…","رسالة…","संदेश…","Mensagem…","Nachricht…","メッセージ…"));
        input.setSingleLine(false);
        input.setMaxLines(3);
        input.setFilters(new InputFilter[]{new InputFilter.LengthFilter(500)});
        LinearLayout.LayoutParams inLp = new LinearLayout.LayoutParams(0, dp(54), 1f);
        sendBar.addView(input, inLp);
        Space gap = new Space(this); sendBar.addView(gap, new LinearLayout.LayoutParams(dp(8), 1));
        Button send = new Button(this);
        send.setText("➤");
        send.setTextSize(22);
        send.setTextColor(Color.WHITE);
        send.setBackground(bg(0xFFB94764, 16, 0, 0));
        sendBar.addView(send, new LinearLayout.LayoutParams(dp(58), dp(54)));
        col.addView(sendBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        send.setOnClickListener(v -> {
            String text = input.getText().toString().trim();
            if (text.length() == 0) return;
            sendMessage(text, input, send);
        });

        fetchMessages();
    }

    void startPolling() {
        if (!backendConfigured()) return;
        polling = true;
        handler.removeCallbacks(refreshRunnable);
        handler.post(refreshRunnable);
    }

    void stopPolling() {
        polling = false;
        handler.removeCallbacks(refreshRunnable);
    }

    void sendMessage(String text, EditText input, Button send) {
        send.setEnabled(false);
        final String sv = prefs.getString("server", "");
        final String al = prefs.getString("alliance", "");
        final String ni = prefs.getString("nick", "");
        final String uid = prefs.getString("user_id", "");
        new Thread(() -> {
            try {
                JSONObject j = new JSONObject();
                String firebaseUid = ensureFirebaseProfile();
                j.put("uid", firebaseUid);
                j.put("server", sv);
                j.put("alliance", al);
                j.put("nickname", ni);
                j.put("text", text);
                j.put("timestamp", System.currentTimeMillis());
                request("POST", authenticatedEndpoint("messages.json"), j.toString());
                runOnUiThread(() -> {
                    input.setText("");
                    send.setEnabled(true);
                    fetchMessages();
                });
            } catch (Exception ex) {
                runOnUiThread(() -> {
                    send.setEnabled(true);
                    Toast.makeText(MainActivity.this, view.tr("Не удалось отправить сообщение","Could not send message","Impossible d'envoyer le message","无法发送消息","No se pudo enviar el mensaje","تعذر إرسال الرسالة","संदेश भेजा नहीं जा सका","Não foi possível enviar a mensagem","Nachricht konnte nicht gesendet werden","メッセージを送信できませんでした"), Toast.LENGTH_SHORT).show();
                });
            }
        }).start();
    }

    void fetchMessages() {
        if (!backendConfigured()) return;
        new Thread(() -> {
            try {
                String body = request("GET", authenticatedEndpoint("messages.json"), null);
                ArrayList<ChatMessage> fresh = new ArrayList<>();
                if (body != null && !body.trim().equals("null") && body.trim().startsWith("{")) {
                    JSONObject all = new JSONObject(body);
                    Iterator<String> keys = all.keys();
                    while (keys.hasNext()) {
                        String key = keys.next();
                        JSONObject m = all.optJSONObject(key);
                        if (m == null) continue;
                        ChatMessage cm = new ChatMessage();
                        cm.server = m.optString("server", "?");
                        cm.alliance = m.optString("alliance", "???");
                        cm.nick = m.optString("nickname", "Player");
                        cm.text = m.optString("text", "");
                        cm.timestamp = m.optLong("timestamp", 0);
                        cm.userId = m.optString("uid", "");
                        if (cm.text.length() > 0) fresh.add(cm);
                    }
                }
                Collections.sort(fresh, Comparator.comparingLong(a -> a.timestamp));
                if (fresh.size() > 100) fresh = new ArrayList<>(fresh.subList(fresh.size()-100, fresh.size()));
                final ArrayList<ChatMessage> finalFresh = fresh;
                runOnUiThread(() -> {
                    messages.clear();
                    messages.addAll(finalFresh);
                    if (messageAdapter != null) messageAdapter.notifyDataSetChanged();
                    if (messageList != null && messages.size() > 0) messageList.setSelection(messages.size()-1);
                });
            } catch (Exception ignored) { }
        }).start();
    }


    String ensureFirebaseProfile() throws Exception {
        String token = getFirebaseIdToken();
        String uid = getFirebaseUid(token);
        JSONObject profile = new JSONObject();
        profile.put("server", prefs.getString("server", ""));
        profile.put("alliance", prefs.getString("alliance", ""));
        profile.put("nickname", prefs.getString("nick", ""));
        request("PUT",
                endpoint("users/" + uid + ".json") + "?auth=" + URLEncoder.encode(token, "UTF-8"),
                profile.toString());
        return uid;
    }

    String getFirebaseUid(String token) throws Exception {
        String uid = prefs.getString("firebase_uid", "");
        if (uid.length() > 0) return uid;

        JSONObject payload = new JSONObject();
        payload.put("idToken", token);
        JSONObject lookup = new JSONObject(request(
                "POST",
                "https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=" + FIREBASE_API_KEY,
                payload.toString()));
        if (lookup.optJSONArray("users") != null && lookup.optJSONArray("users").length() > 0) {
            uid = lookup.optJSONArray("users").optJSONObject(0).optString("localId", "");
        }
        if (uid.length() == 0) throw new RuntimeException("Firebase uid missing");
        prefs.edit().putString("firebase_uid", uid).apply();
        return uid;
    }

    String authenticatedEndpoint(String path) throws Exception {
        String token = getFirebaseIdToken();
        return endpoint(path) + "?auth=" + URLEncoder.encode(token, "UTF-8");
    }

    String getFirebaseIdToken() throws Exception {
        long now = System.currentTimeMillis();
        if (firebaseIdToken.length() > 0 && now < firebaseTokenExpiryMs) return firebaseIdToken;
        synchronized (firebaseAuthLock) {
            now = System.currentTimeMillis();
            if (firebaseIdToken.length() > 0 && now < firebaseTokenExpiryMs) return firebaseIdToken;

            String refresh = prefs.getString("firebase_refresh_token", "");
            if (refresh.length() > 0) {
                try {
                    JSONObject refreshed = new JSONObject(formRequest(
                            "https://securetoken.googleapis.com/v1/token?key=" + FIREBASE_API_KEY,
                            "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(refresh, "UTF-8")));
                    firebaseIdToken = refreshed.optString("id_token", "");
                    String newRefresh = refreshed.optString("refresh_token", refresh);
                    long expires = Long.parseLong(refreshed.optString("expires_in", "3600"));
                    firebaseTokenExpiryMs = System.currentTimeMillis() + Math.max(60, expires - 120) * 1000L;
                    prefs.edit().putString("firebase_refresh_token", newRefresh).apply();
                    if (firebaseIdToken.length() > 0) return firebaseIdToken;
                } catch (Exception ignored) {
                    prefs.edit().remove("firebase_refresh_token").apply();
                }
            }

            JSONObject signed = new JSONObject(request(
                    "POST",
                    "https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + FIREBASE_API_KEY,
                    "{\"returnSecureToken\":true}"));
            firebaseIdToken = signed.optString("idToken", "");
            String newRefresh = signed.optString("refreshToken", "");
            String firebaseUid = signed.optString("localId", "");
            long expires = Long.parseLong(signed.optString("expiresIn", "3600"));
            firebaseTokenExpiryMs = System.currentTimeMillis() + Math.max(60, expires - 120) * 1000L;
            SharedPreferences.Editor authEdit = prefs.edit();
            if (newRefresh.length() > 0) authEdit.putString("firebase_refresh_token", newRefresh);
            if (firebaseUid.length() > 0) authEdit.putString("firebase_uid", firebaseUid);
            authEdit.apply();
            if (firebaseIdToken.length() == 0) throw new RuntimeException("Firebase anonymous auth failed");
            return firebaseIdToken;
        }
    }

    String formRequest(String url, String formBody) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        byte[] data = formBody.getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = c.getOutputStream()) { os.write(data); }
        int code = c.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line; while ((line = br.readLine()) != null) sb.append(line);
            }
        }
        c.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("HTTP " + code + ": " + sb);
        return sb.toString();
    }

    String endpoint(String path) {
        String base = FIREBASE_URL.endsWith("/") ? FIREBASE_URL.substring(0, FIREBASE_URL.length()-1) : FIREBASE_URL;
        return base + "/" + path;
    }

    String request(String method, String url, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestMethod(method);
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        c.setRequestProperty("Accept", "application/json");
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            byte[] data = body.getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = c.getOutputStream()) { os.write(data); }
        }
        int code = c.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        StringBuilder sb = new StringBuilder();
        if (is != null) {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
                String line; while ((line = br.readLine()) != null) sb.append(line);
            }
        }
        c.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("HTTP " + code + ": " + sb);
        return sb.toString();
    }

    void hideKeyboard() {
        View f = getCurrentFocus();
        if (f != null) {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(f.getWindowToken(), 0);
            f.clearFocus();
        }
    }

    @Override protected void onPause() {
        super.onPause();
        stopPolling();
    }

    @Override protected void onResume() {
        super.onResume();
        if (view != null && view.screen == 1 && view.tab == 1 && prefs.getBoolean("registered", false)) startPolling();
    }

    static class ChatMessage {
        String server, alliance, nick, text, userId;
        long timestamp;
    }

    class MessageAdapter extends BaseAdapter {
        final Context ctx;
        final List<ChatMessage> data;
        final SimpleDateFormat time = new SimpleDateFormat("HH:mm", Locale.getDefault());
        MessageAdapter(Context c, List<ChatMessage> d) { ctx=c; data=d; }
        @Override public int getCount(){ return data.size(); }
        @Override public Object getItem(int p){ return data.get(p); }
        @Override public long getItemId(int p){ return p; }
        @Override public View getView(int pos, View convert, ViewGroup parent) {
            ChatMessage m = data.get(pos);
            LinearLayout card = new LinearLayout(ctx);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(13), dp(9), dp(13), dp(9));
            boolean mine = prefs.getString("firebase_uid", "").equals(m.userId);
            card.setBackground(bg(mine ? 0xD54B2835 : 0xC91B151C, 15, mine ? 0xFF6B3D4D : 0xFF382B34, 1));

            LinearLayout top = new LinearLayout(ctx);
            top.setOrientation(LinearLayout.HORIZONTAL);
            TextView who = tv("["+m.server+"] ["+m.alliance+"] "+m.nick, 13, mine ? 0xFFD7B88A : 0xFFE2D9DF, true);
            top.addView(who, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView tm = tv(m.timestamp > 0 ? time.format(new Date(m.timestamp)) : "", 11, 0xFF817780, false);
            top.addView(tm, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            card.addView(top, lpMatchWrap());

            TextView msg = tv(m.text, 16, Color.WHITE, false);
            msg.setPadding(0, dp(5), 0, 0);
            msg.setTextIsSelectable(true);
            card.addView(msg, lpMatchWrap());
            return card;
        }
    }

    class CompanionView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap castle, face;
        int screen = 0; // 0 intro, 1 main
        int tab = 0; // 0 info, 1 chat
        int language;
        float[] sx = new float[24], sy = new float[24], sr = new float[24];
        RectF langRect = new RectF(), buttonRect = new RectF(), navRect = new RectF(), infoRect = new RectF(), chatRect = new RectF();

        CompanionView(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            castle = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("castle","drawable",getPackageName()));
            face = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("face_logo","drawable",getPackageName()));
            language = prefs.getInt("lang", 0);
            Random r = new Random(14);
            for (int i=0;i<sx.length;i++) { sx[i]=r.nextFloat(); sy[i]=r.nextFloat(); sr[i]=0.8f+r.nextFloat()*1.6f; }
            stroke.setStyle(Paint.Style.STROKE);
        }

        String tr(String... v) { return v[Math.max(0, Math.min(language, v.length-1))]; }
        String langCode() { return new String[]{"RU","EN","FR","中文","ES","AR","HI","PT","DE","日本"}[language]; }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            Paint bg=new Paint();
            bg.setShader(new LinearGradient(0,0,0,h,Color.rgb(38,19,29),Color.rgb(9,7,12),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,bg);
            Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
            halo.setShader(new RadialGradient(w*.66f,h*.1f,w*.6f,new int[]{0x302F0D1A,0x00100010},null,Shader.TileMode.CLAMP));
            c.drawCircle(w*.66f,h*.1f,w*.6f,halo);
            drawStars(c,w,h);
            if(screen==0) drawIntro(c,w,h); else drawMain(c,w,h);
        }

        void drawStars(Canvas c,float w,float h){
            p.setColor(0x305F5060);
            for(int i=0;i<sx.length;i++) c.drawCircle(sx[i]*w, sy[i]*h, sr[i], p);
        }

        void drawIntro(Canvas c,float w,float h){
            float s=w/691f;

            // Full-screen welcome artwork. The castle and red moon are used ONLY here.
            if (castle != null) {
                float scale = Math.max(w / castle.getWidth(), h / castle.getHeight());
                float srcW = w / scale;
                float srcH = h / scale;
                float left = (castle.getWidth() - srcW) / 2f;
                float top = Math.max(0, (castle.getHeight() - srcH) / 2f);
                Rect src = new Rect((int)left, (int)top, (int)(left + srcW), (int)(top + srcH));
                RectF dst = new RectF(0, 0, w, h);
                c.drawBitmap(castle, src, dst, p);
            }
            Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG);
            shade.setShader(new LinearGradient(0, 0, 0, h, new int[]{0x8A100810,0x55210D14,0xB909070C}, null, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, shade);

            RectF fr=new RectF(49*s,48*s,116*s,115*s); c.drawBitmap(face,null,fr,p);
            p.setColor(Color.rgb(215,184,138)); p.setTextSize(18*s); p.setTypeface(Typeface.create("sans",Typeface.NORMAL));
            c.drawText("N O D   C O M P A N I O N",132*s,90*s,p);
            langRect.set(w-183*s,42*s,w-48*s,118*s); drawRounded(c,langRect,20*s,0x45100C14,0xAA8A6D77,1.5f*s);
            drawGlobe(c,langRect.left+40*s,langRect.centerY(),12*s,Color.rgb(215,184,138));
            p.setColor(Color.WHITE); p.setTextSize(20*s); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(langCode(),langRect.left+65*s,langRect.centerY()+7*s,p);
            p.setColor(Color.rgb(215,184,138)); p.setTextSize(12*s); c.drawText("▾",langRect.right-26*s,langRect.centerY()+3*s,p);

            p.setTextAlign(Paint.Align.CENTER);
            p.setColor(Color.WHITE); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); p.setTextSize(43*s);
            c.drawText("NATIONS OF",w/2,h*.54f,p);
            c.drawText("DARKNESS",w/2,h*.60f,p);
            p.setColor(0xFFD2C8CD); p.setTextSize(22*s);
            c.drawText(tr("Твой помощник в мире тьмы.","Your companion in the world of darkness.","Votre compagnon dans le monde des ténèbres.","你在黑暗世界中的助手。","Tu compañero en el mundo de la oscuridad.","رفيقك في عالم الظلام.","अंधकार की दुनिया में आपका साथी।","Seu companheiro no mundo das trevas.","Dein Begleiter in der Welt der Dunkelheit.","闇の世界のあなたの相棒。"),w/2,h*.655f,p);

            buttonRect.set(49*s,h-235*s,w-49*s,h-135*s); drawRounded(c,buttonRect,26*s,0xFFB94764,0x00000000,0);
            p.setColor(Color.WHITE); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(27*s); c.drawText(tr("Начать","Start","Commencer","开始","Comenzar","ابدأ","शुरू करें","Começar","Starten","開始"),w/2,buttonRect.centerY()+9*s,p);
            p.setColor(0xFFB7ADB4); p.setTypeface(Typeface.DEFAULT); p.setTextSize(17*s); c.drawText(tr("Версия 0.5.3","Version 0.5.3","Version 0.5.3","版本 0.5.3","Versión 0.5.3","الإصدار 0.5.3","संस्करण 0.5.3","Versão 0.5.3","Version 0.5.3","バージョン 0.5.3"),w/2,h-53*s,p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        void drawMain(Canvas c,float w,float h){
            float s=w/691f;
            float cx=73*s, cy=72*s, rr=24*s;
            stroke.setStrokeWidth(1.2f*s); stroke.setColor(0x554D3D4B); c.drawCircle(cx,cy,rr+7*s,stroke); c.drawCircle(cx,cy,rr+2*s,stroke);
            p.setColor(Color.rgb(236,218,194)); c.drawCircle(cx-5*s,cy,9*s,p);
            p.setColor(Color.rgb(38,19,29)); c.drawCircle(cx-1*s,cy-3*s,9*s,p);
            p.setColor(Color.rgb(236,218,194)); c.drawCircle(cx+10*s,cy-9*s,1.8f*s,p); c.drawCircle(cx+14*s,cy+2*s,1.2f*s,p);
            p.setColor(Color.rgb(248,246,244)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(26*s); c.drawText("NoD Companion",120*s,82*s,p);

            langRect.set(w-176*s,35*s,w-42*s,112*s); drawRounded(c,langRect,22*s,0x12100B12,0xFF3C2D37,2*s);
            drawGlobe(c,langRect.left+37*s,langRect.centerY(),12*s,Color.rgb(215,184,138));
            p.setColor(Color.WHITE); p.setTextSize(20*s); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(langCode(),langRect.left+62*s,langRect.centerY()+7*s,p);
            p.setColor(Color.rgb(215,184,138)); p.setTextSize(12*s); c.drawText("▾",langRect.right-25*s,langRect.centerY()+3*s,p);

            if (keyboardVisible) return;

            navRect.set(28*s,h-178*s,w-28*s,h-62*s); drawRounded(c,navRect,34*s,0x15161119,0xFF3C2E39,2*s);
            infoRect.set(navRect.left+10*s,navRect.top+10*s,navRect.centerX()-4*s,navRect.bottom-10*s);
            chatRect.set(navRect.centerX()+4*s,navRect.top+10*s,navRect.right-10*s,navRect.bottom-10*s);
            RectF sel = tab==0 ? infoRect : chatRect; drawRounded(c,sel,26*s,0xFF4B2835,0x00000000,0);

            float iconY=navRect.top+43*s;
            stroke.setStrokeWidth(2.7f*s); stroke.setColor(tab==0?Color.WHITE:Color.rgb(189,181,188)); c.drawCircle(infoRect.centerX(),iconY,15*s,stroke);
            p.setColor(tab==0?Color.WHITE:Color.rgb(189,181,188)); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(21*s); c.drawText("i",infoRect.centerX(),iconY+7*s,p);
            p.setTextSize(19*s); c.drawText(tr("Информация","Information","Informations","信息","Información","معلومات","जानकारी","Informações","Information","情報"),infoRect.centerX(),navRect.bottom-22*s,p);
            stroke.setColor(tab==1?Color.WHITE:Color.rgb(189,181,188)); RectF b=new RectF(chatRect.centerX()-15*s,iconY-11*s,chatRect.centerX()+15*s,iconY+9*s); c.drawRect(b,stroke); Path tail=new Path(); tail.moveTo(chatRect.centerX()-6*s,iconY+9*s); tail.lineTo(chatRect.centerX()-11*s,iconY+16*s); tail.lineTo(chatRect.centerX()+1*s,iconY+9*s); c.drawPath(tail,stroke);
            p.setColor(tab==1?Color.WHITE:Color.rgb(189,181,188)); p.setTextSize(19*s); c.drawText(tr("Чат","Chat","Chat","聊天","Chat","دردشة","चैट","Chat","Chat","チャット"),chatRect.centerX(),navRect.bottom-22*s,p);

            p.setColor(Color.rgb(126,118,126)); p.setTypeface(Typeface.DEFAULT); p.setTextSize(17*s); c.drawText(tr("Версия 0.5.3","Version 0.5.3","Version 0.5.3","版本 0.5.3","Versión 0.5.3","الإصدار 0.5.3","संस्करण 0.5.3","Versão 0.5.3","Version 0.5.3","バージョン 0.5.3"),w/2,h-18*s,p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        void drawRounded(Canvas c,RectF r,float radius,int fill,int line,float sw){
            p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawRoundRect(r,radius,radius,p);
            if(sw>0){ stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(sw); stroke.setColor(line); c.drawRoundRect(r,radius,radius,stroke); }
        }

        void drawGlobe(Canvas c,float x,float y,float r,int color){
            stroke.setColor(color); stroke.setStrokeWidth(2f); c.drawCircle(x,y,r,stroke); c.drawOval(new RectF(x-r*.45f,y-r,x+r*.45f,y+r),stroke); c.drawLine(x-r,y,x+r,y,stroke);
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=e.getX(), y=e.getY();
            if(langRect.contains(x,y)){ showLanguageDialog(); return true; }
            if(screen==0 && buttonRect.contains(x,y)){ screen=1; invalidate(); onTabChanged(tab); return true; }
            if(screen==1){
                if(infoRect.contains(x,y)){tab=0;invalidate();onTabChanged(tab);return true;}
                if(chatRect.contains(x,y)){tab=1;invalidate();onTabChanged(tab);return true;}
            }
            return true;
        }
    }
}
