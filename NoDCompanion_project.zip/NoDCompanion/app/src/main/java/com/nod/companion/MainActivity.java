package com.nod.companion;

import android.app.AlertDialog;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

import java.util.Random;

public class MainActivity extends Activity {
    CompanionView view;
    SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Color.rgb(36,19,28));
        w.setNavigationBarColor(Color.rgb(9,7,12));
        prefs = getSharedPreferences("nod", MODE_PRIVATE);
        view = new CompanionView(this);
        setContentView(view);
    }

    public void showLanguageDialog() {
        final String[] names = {"Русский","English","Français","简体中文","Español","العربية","हिन्दी","Português","Deutsch","日本語"};
        int checked = view.language;
        AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle(view.tr("Выберите язык","Choose language","Choisissez la langue","选择语言","Elige idioma","اختر اللغة","भाषा चुनें","Escolha o idioma","Sprache wählen","言語を選択"))
                .setSingleChoiceItems(names, checked, (dialog, which) -> {
                    view.language = which;
                    prefs.edit().putInt("lang", which).apply();
                    view.invalidate();
                    dialog.dismiss();
                })
                .setNegativeButton(view.tr("ОТМЕНА","CANCEL","ANNULER","取消","CANCELAR","إلغاء","रद्द करें","CANCELAR","ABBRECHEN","キャンセル"), null)
                .create();
        dlg.setOnShowListener(d -> {
            if (dlg.getWindow() != null) dlg.getWindow().setBackgroundDrawable(new ColorDrawable(Color.rgb(68,68,68)));
            dlg.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.rgb(185,71,100));
        });
        dlg.show();
    }

    class CompanionView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        Bitmap castle, face;
        int screen = 0; // 0 intro, 1 main
        int tab = 0; // 0 info, 1 chat
        int language;
        float[] sx = new float[24], sy = new float[24], sr = new float[24];
        RectF langRect = new RectF(), buttonRect = new RectF(), navRect = new RectF(), infoRect = new RectF(), chatRect = new RectF();

        CompanionView(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            castle = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("castle","drawable",getPackageName()));
            face = BitmapFactory.decodeResource(getResources(), getResources().getIdentifier("face_logo","drawable",getPackageName()));
            language = prefs.getInt("lang", 0);
            Random r = new Random(14);
            for (int i=0;i<sx.length;i++) { sx[i]=r.nextFloat(); sy[i]=r.nextFloat(); sr[i]=0.8f+r.nextFloat()*1.6f; }
            stroke.setStyle(Paint.Style.STROKE);
        }

        String tr(String... v) { return v[Math.max(0, Math.min(language, v.length-1))]; }
        String langCode() { return new String[]{"RU","EN","FR","中文","ES","AR","HI","PT","DE","日本"}[language]; }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            Paint bg=new Paint();
            bg.setShader(new LinearGradient(0,0,0,h,Color.rgb(38,19,29),Color.rgb(9,7,12),Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,bg);
            // subtle red halo
            Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
            halo.setShader(new RadialGradient(w*.66f,h*.1f,w*.6f,new int[]{0x302F0D1A,0x00100010},null,Shader.TileMode.CLAMP));
            c.drawCircle(w*.66f,h*.1f,w*.6f,halo);
            drawStars(c,w,h);
            if(screen==0) drawIntro(c,w,h); else drawMain(c,w,h);
        }

        void drawStars(Canvas c,float w,float h){
            p.setColor(0x305F5060);
            for(int i=0;i<sx.length;i++) c.drawCircle(sx[i]*w, sy[i]*h, sr[i], p);
        }

        void drawIntro(Canvas c,float w,float h){
            float s=w/691f;
            // header face
            RectF fr=new RectF(49*s,48*s,116*s,115*s); c.drawBitmap(face,null,fr,p);
            p.setColor(Color.rgb(215,184,138)); p.setTextSize(18*s); p.setTypeface(Typeface.create("sans",Typeface.NORMAL));
            c.drawText("N O D   C O M P A N I O N",132*s,90*s,p);
            langRect.set(w-183*s,42*s,w-48*s,118*s); drawRounded(c,langRect,20*s,0x15100C14,0xFF3B2D36,2*s);
            drawGlobe(c,langRect.left+40*s,langRect.centerY(),12*s,Color.rgb(215,184,138));
            p.setColor(Color.WHITE); p.setTextSize(20*s); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(langCode(),langRect.left+65*s,langRect.centerY()+7*s,p);
            p.setColor(Color.rgb(215,184,138)); p.setTextSize(12*s); c.drawText("▾",langRect.right-26*s,langRect.centerY()+3*s,p);

            float imageTop=245*s;
            float imageW=w-96*s;
            float imageH=imageW*castle.getHeight()/castle.getWidth();
            RectF cr=new RectF(48*s,imageTop,w-48*s,imageTop+imageH);
            c.drawBitmap(castle,null,cr,p);

            p.setColor(Color.rgb(248,246,244)); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(43*s);
            c.drawText("NATIONS OF",w/2,cr.bottom+72*s,p); c.drawText("DARKNESS",w/2,cr.bottom+146*s,p);
            p.setColor(Color.rgb(170,163,169)); p.setTextSize(22*s); c.drawText(tr(
                "Твой помощник в мире тьмы.","Your companion in the world of darkness.","Votre compagnon dans le monde des ténèbres.","你在黑暗世界中的助手。","Tu compañero en el mundo de la oscuridad.","رفيقك في عالم الظلام.","अंधकार की दुनिया में आपका साथी।","Seu companheiro no mundo das trevas.","Dein Begleiter in der Welt der Dunkelheit.","闇の世界のあなたの相棒。"),w/2,cr.bottom+214*s,p);

            buttonRect.set(49*s,h-235*s,w-49*s,h-135*s); drawRounded(c,buttonRect,26*s,0xFFB94764,0x00000000,0);
            p.setColor(Color.WHITE); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(27*s); c.drawText(tr("Начать","Start","Commencer","开始","Comenzar","ابدأ","शुरू करें","Começar","Starten","開始"),w/2,buttonRect.centerY()+9*s,p);
            p.setColor(Color.rgb(126,118,126)); p.setTypeface(Typeface.DEFAULT); p.setTextSize(17*s); c.drawText("Версия 0.4.0",w/2,h-53*s,p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        void drawMain(Canvas c,float w,float h){
            float s=w/691f;
            // Moon logo
            float cx=73*s, cy=72*s, rr=24*s;
            stroke.setStrokeWidth(1.2f*s); stroke.setColor(0x554D3D4B); c.drawCircle(cx,cy,rr+7*s,stroke); c.drawCircle(cx,cy,rr+2*s,stroke);
            p.setColor(Color.rgb(236,218,194)); c.drawCircle(cx-5*s,cy,9*s,p);
            p.setColor(Color.rgb(38,19,29)); c.drawCircle(cx-1*s,cy-3*s,9*s,p);
            p.setColor(Color.rgb(236,218,194)); c.drawCircle(cx+10*s,cy-9*s,1.8f*s,p); c.drawCircle(cx+14*s,cy+2*s,1.2f*s,p);
            p.setColor(Color.rgb(248,246,244)); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(26*s); c.drawText("NoD Companion",120*s,82*s,p);

            langRect.set(w-176*s,35*s,w-42*s,112*s); drawRounded(c,langRect,22*s,0x12100B12,0xFF3C2D37,2*s);
            drawGlobe(c,langRect.left+37*s,langRect.centerY(),12*s,Color.rgb(215,184,138));
            p.setColor(Color.WHITE); p.setTextSize(20*s); p.setTypeface(Typeface.DEFAULT_BOLD); c.drawText(langCode(),langRect.left+62*s,langRect.centerY()+7*s,p);
            p.setColor(Color.rgb(215,184,138)); p.setTextSize(12*s); c.drawText("▾",langRect.right-25*s,langRect.centerY()+3*s,p);

            navRect.set(28*s,h-178*s,w-28*s,h-62*s); drawRounded(c,navRect,34*s,0x15161119,0xFF3C2E39,2*s);
            infoRect.set(navRect.left+10*s,navRect.top+10*s,navRect.centerX()-4*s,navRect.bottom-10*s);
            chatRect.set(navRect.centerX()+4*s,navRect.top+10*s,navRect.right-10*s,navRect.bottom-10*s);
            RectF sel = tab==0 ? infoRect : chatRect; drawRounded(c,sel,26*s,0xFF4B2835,0x00000000,0);

            float iconY=navRect.top+43*s;
            // info icon
            stroke.setStrokeWidth(2.7f*s); stroke.setColor(tab==0?Color.WHITE:Color.rgb(189,181,188)); c.drawCircle(infoRect.centerX(),iconY,15*s,stroke);
            p.setColor(tab==0?Color.WHITE:Color.rgb(189,181,188)); p.setTextAlign(Paint.Align.CENTER); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(21*s); c.drawText("i",infoRect.centerX(),iconY+7*s,p);
            p.setTextSize(19*s); c.drawText(tr("Информация","Information","Informations","信息","Información","معلومات","जानकारी","Informações","Information","情報"),infoRect.centerX(),navRect.bottom-22*s,p);
            // chat icon bubble
            stroke.setColor(tab==1?Color.WHITE:Color.rgb(189,181,188)); RectF b=new RectF(chatRect.centerX()-15*s,iconY-11*s,chatRect.centerX()+15*s,iconY+9*s); c.drawRect(b,stroke); Path tail=new Path(); tail.moveTo(chatRect.centerX()-6*s,iconY+9*s); tail.lineTo(chatRect.centerX()-11*s,iconY+16*s); tail.lineTo(chatRect.centerX()+1*s,iconY+9*s); c.drawPath(tail,stroke);
            p.setColor(tab==1?Color.WHITE:Color.rgb(189,181,188)); p.setTextSize(19*s); c.drawText(tr("Чат","Chat","Chat","聊天","Chat","دردشة","चैट","Chat","Chat","チャット"),chatRect.centerX(),navRect.bottom-22*s,p);

            p.setColor(Color.rgb(126,118,126)); p.setTypeface(Typeface.DEFAULT); p.setTextSize(17*s); c.drawText("Версия 0.4.0",w/2,h-18*s,p);
            p.setTextAlign(Paint.Align.LEFT);
        }

        void drawRounded(Canvas c,RectF r,float radius,int fill,int line,float sw){
            p.setStyle(Paint.Style.FILL); p.setColor(fill); c.drawRoundRect(r,radius,radius,p);
            if(sw>0){ stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(sw); stroke.setColor(line); c.drawRoundRect(r,radius,radius,stroke); }
        }

        void drawGlobe(Canvas c,float x,float y,float r,int color){
            stroke.setColor(color); stroke.setStrokeWidth(2f); c.drawCircle(x,y,r,stroke); c.drawOval(new RectF(x-r*.45f,y-r,x+r*.45f,y+r),stroke); c.drawLine(x-r,y,x+r,y,stroke);
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=e.getX(), y=e.getY();
            if(langRect.contains(x,y)){ showLanguageDialog(); return true; }
            if(screen==0 && buttonRect.contains(x,y)){ screen=1; invalidate(); return true; }
            if(screen==1){
                if(infoRect.contains(x,y)){tab=0;invalidate();return true;}
                if(chatRect.contains(x,y)){tab=1;invalidate();return true;}
            }
            return true;
        }
    }
}
